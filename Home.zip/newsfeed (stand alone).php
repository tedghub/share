<?php

/////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////
// media images for articles are in <img src="" <media:content url="" or <media:thumbnails
// split rss url into <item>s or <entry>s and parse them for images until you find one bigger than 40 X 40 
//
// newsfeed icon and title is usually in <image> tag before first article. icon is in <url> title is in <title>
// 
/////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////

function display_txt($t)// temporary for debugging
{	$t = str_replace('<','&lt;',$t);  $t = str_replace('>','&gt;',$t); echo $t;
}

include 'functions.php';

// GMT unless noted
$ur = "http://weblog.philringnalda.com/feed/";// no pictures, uses entry instead of item
//$ur = "http://www.reddit.com/.rss";// img, uses entry instead of item, uses &quot; for quote
//$ur = "http://rss.cnn.com/rss/cnn_topstories.rss";// media:content, title in <title><![CDATA[   ]]></title
//$ur = "http://feeds.feedburner.com/web20Show";// media:content, first image in all is a 96X96 icon. Some have a real 2nd image
//$ur = "http://afterdawn.com/news/afterdawn_rss.xml";// img
//$ur = "http://news.google.com/?output=rss";//  img (HTML empty element, terminated with > instead of />)
//$ur = "http://www.flickr.com/services/feeds/photos_public.gne?format=rss2";// img src=, media:content url=, media:thumbnail url=, enclosure url=, time -07:00
//$ur = "https://www.huffingtonpost.com/section/world-news/feed";// enclosure url=, eastern time
//$ur = "http://feeds.bbci.co.uk/news/world/rss.xml";// media:thumbnail, title in <title><![CDATA[   ]]></title> GMT
$ur = "https://www.npr.org/rss/rss.php";// img, eastern tim
//$ur = "http://rss.nytimes.com/services/xml/rss/nyt/HomePage.xml";// media:content url=
//$ur = "http://feeds.reuters.com/reuters/topNews"; //  eastern time
//$ur = "http://feeds.reuters.com/Reuters/domesticNews";//  eastern time
//$ur = "http://rssfeeds.usatoday.com/usatoday-NewsTopStories";//  eastern time
//$ur = "http://www.nasa.gov/rss/image_of_the_day.rss";// edt zone300 is_dst 1
//$ur = "http://www.pbs.org/wgbh/nova/rss/nova.xml";// zone 240
//$ur = "http://feeds.sciencedaily.com/sciencedaily";// edt zone300 is_dst 1
$ur = "http://feeds.bbci.co.uk/news/rss.xml?edition=us";
//$ur = "http://osnews.com/files/recent.rdf";// no pictures, no time
//$ur = "https://feeds.npr.org/1001/rss.xml";
//$ur = "https://www.npr.org/rss/rss.php?id=1001";
//$ur = "https://www.cbsnews.com/latest/rss/us";
//$ur = "https://www.yahoo.com/news/rss";
//$ur = "https://www.yahoo.com/news/rss/topstories";
//$ur = "https://www.theonion.com/rss";
//$ur = "https://www.theguardian.com/us-news/rss";// media:content url=

echo $ur;
//return;
$st = get_page($ur);
display_txt($st);
$st = preg_replace('/[[:^print:]]/', '', $st);// replace all unprintable characters
echo "before get_articles<br><br>";
$ar =  get_articles($st);
return;

echo count($ar);
display_txt($st);

?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="w3.css">
	<title>Php News Feed Test</title>
	<script>
		function toggle(id){ document.getElementById(id).classList.toggle("w3-show");}

		function hoverdiv(e,divid)// can not have popup cover mouse cursor or a mouseout event will be triggered
		{	var left  = e.clientX  + 20 + "px";
			var top  = e.clientY + 20 + "px";
	
			var div = document.getElementById(divid);

			div.style.left = left;
			div.style.top = top;
			//div.style.display = 'inline';

			toggle(divid);
			return false;
		}

		function hide(divid)
		{	var div = document.getElementById(divid);

			div.style.display = 'none';

			return false;
		}

	</script>
	<style>
		.arttitle:hover {
			text-decoration: underline;
		}
	</style>
</head>
<body>
<?php

echo "Site = " . $ur . "<br><br>";

$tar = get_elements($st, 'image');

foreach ($tar as $its)
{	$tar2 = get_elements($its, 'title');
	$ts = strip_tags($tar2[0]);
	if(!empty($ts)) break; 
}

if(empty($ts)) // if still no title
{	$e = stripos( $st, '<entry');// find first entry tag
	if ($e === false) $e = stripos( $st, '<item');// if no entry find first item tag
	if ($e === false) $ts = 'Not a valid rss';// if no item find first item tag
	else
	{	$ts = substr($st, 0, $e); // get buffer up to first atricle
		$tar2 = get_elements($ts, 'title');
		$ts = strip_tags($tar2[0]);
		if(empty($ts)) $ts = 'No title'; // no title make title = No title
	}	
}

echo "Title = [" . $ts;
//display_txt($tar[0]);
echo "]<br><br>";


$sz = 70;// height of article div
$al = count($ar);// length of articles array

// fully display first 3 articles
for($a = 0; $a < 3 && $a < $al; $a++)
{	$its = $ar[$a];
	$date = $its['date'];
	echo 'ARTICLE Updated: ';
	if(empty($date)) $ago = 'No date in feed';
	else
	{	echo date_format($date,"D, M d Y - g:i A");
		echo "<br>";

		// display hours minutes or days ago
		$di = date_diff($date, date_create() );
		if($di->d > 0) $ago = $di->days . ' days';
		elseif($di->h > 0) $ago = $di->h . ' hours';
		else $ago = $di->i . ' minutes';
		//echo $ago . ' ago<br>';
		$ago = '('.$ago . '  ago) -';
	}
	?>
	<div style="height:<?=$sz?>px; overflow: hidden; background-color:ivory;"  onmouseover="hoverdiv(event,'<?=$a?>')" onmouseout="hoverdiv(event,'<?=$a?>')" >
		<a href="<?=$its['link']?>" style="text-decoration:none" target="_blank">
			<img src="<?=$its['image']?>" style="float:left" height="<?=$sz?>" >
			<b><?=$its['title']?></b>
			<span style="white-space:nowrap; font-size: 90%; margin: 0 .2em"><?=$ago?></span>
			<?=$its['desc']?>
		</a>
	</div>
	<div id="<?=$a?>" style="overflow: hidden; background-color:white; width: 30%; display: none; position: fixed; padding:10px; border: 1px solid lightgrey;" >
			<img src="<?=$its['image']?>" style="float:left" height="<?=$sz?>" >
			<b><?=$its['title']?></b><br>
			<span style="white-space:nowrap; font-size: 90%; margin: 0 .2em"><?=$ago?></span>
			<?=$its['desc']?>
	</div>
	<br>
	<?php
}
for(; $a < $al; $a++)
{	$its = $ar[$a];
	?>
	<div class="arttitle" onmouseover="hoverdiv(event,'<?=$a?>')" onmouseout="hoverdiv(event,'<?=$a?>')" style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" >
		>
		<a href="<?=$its['link']?>" style="text-decoration:none" target="_blank"><?=$its['title']?>
		</a>
		<br>
	</div>
	<div id="<?=$a?>" style="overflow: hidden; background-color:white; width: 30%; display: none; position: fixed; padding:10px; border: 1px solid lightgrey;" >
			<img src="<?=$its['image']?>" style="float:left" height="<?=$sz?>" >
			<b><?=$its['title']?></b><br>
			<span style="white-space:nowrap; font-size: 90%; margin: 0 .2em"><?=$ago?></span>
			<?=$its['desc']?>
	</div>
	<?php
}

echo '<br><br>'; display_txt($st);
?>
</body>
</html>
<?php


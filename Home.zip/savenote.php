<?php
$db = new SQLite3('teds');
$st = str_replace('"','""',$_GET['c']);
$db->exec('UPDATE frames Set contents="' . $st . '" WHERE id=' . $_GET['f']);


<?php
include 'functions.php';

function display_txt($t)// temporary for debugging
{	$t = str_replace('<','&lt;',$t);  $t = str_replace('>','&gt;',$t);
	echo $t;
}

$st = get_page('http://feeds.bbci.co.uk/news/rss.xml?edition=us');

//$myfile = fopen("newfile.txt", "w") or die("Unable to open file!");
//fwrite($myfile, $st);
//fclose($myfile);

//$st = preg_replace('/[[:^print:]]/', '', $st);// replace all unprintable characters

$ar =  get_articles($st);
//$ar[] = $_GET["id"];// get feed id from ajax then add it to the end of the array for java to use and remove from array
//echo json_encode($ar, JSON_PARTIAL_OUTPUT_ON_ERROR);// encode php array to JSON array and send it
//echo $st;

$a = $ar[0];
echo $a['title'] . "<br>";
echo $a['desc'] . "<br>";
echo $a['image'] . "<br>";
echo $a['link'] . "<br>";
echo date_format($a['date'],"Y/m/d H:iP") . "<br>";

echo "<br>";

$a = $ar[1];
echo $a['title'] . "<br>";
echo $a['desc'] . "<br>";
echo $a['image'] . "<br>";
echo $a['link'];
echo date_format($a['date'],"Y/m/d H:iP") . "<br>";

/*$its = get_page( 'https://www.bbc.com/news/world-australia-53335745');
    display_txt($its);
		$iar = get_elements($its, 'updated');
		if(count($iar)) $upd = strip_tags($iar[0]);
		else{ $iar = get_elements($its, 'pubDate'); if(count($iar)) $upd = strip_tags($iar[0]);}
//echo $iar[0];

//phpinfo(); /*

/*

function unparse_url($parsed_url) {
  $scheme   = isset($parsed_url['scheme']) ? $parsed_url['scheme'] . '://' : '';
  $host     = isset($parsed_url['host']) ? $parsed_url['host'] : '';
  $port     = isset($parsed_url['port']) ? ':' . $parsed_url['port'] : '';
  $user     = isset($parsed_url['user']) ? $parsed_url['user'] : '';
  $pass     = isset($parsed_url['pass']) ? ':' . $parsed_url['pass']  : '';
  $pass     = ($user || $pass) ? "$pass@" : '';
  $path     = isset($parsed_url['path']) ? $parsed_url['path'] : '';
  $query    = isset($parsed_url['query']) ? '?' . $parsed_url['query'] : '';
  $fragment = isset($parsed_url['fragment']) ? '#' . $parsed_url['fragment'] : '';
  return "$scheme$user$pass$host$port$path$query$fragment";
}

function get_icon($url, $cont){
	$urlparts = parse_url($url); // get parts to url ie. for "https://www.anurl.com/some/path/" scheme = https, host = www.anurl.com, path = /some/path


	// check for link to 'shortcut icon' or 'icon'
	$hd = get_elements($cont, 'head');// get header
	$ls = get_elements($hd[0], 'link');// get links in header
	foreach($ls as $lk)
	{	$re = get_attribute($lk, 'rel');// get rel attribute
		$re = strtolower($re); // convert rel value to lowercase
//display_txt($re);
//echo '<br>n';
		if($re !== 'shortcut icon' && $re !== 'icon') continue;// if not 'shortcut icon' or 'icon' goto next link
		$icol = get_attribute($lk, 'href');// get url of icon
//echo 'icol ='; echo $icol; echo '<br>';
		$icparts = parse_url($icol);// get parts of url
		if(!array_key_exists('scheme', $icparts)) $icparts['scheme'] = $urlparts['scheme'];// if scheme is missing in icon link use the one from base pege
		if(!array_key_exists('host', $icparts)) $icparts['host'] = $urlparts['host'];// do the same as above for host
		$icol = unparse_url($icparts);// reassemble icon url
		if(!strncmp(get_mime($icol), "image", 5)) return $icol; // if mime is an image return
	}


	// try /favicon.ico
	//$icparts = parse_url("/favicon.ico");
	$icol = $url."/favicon.ico";
	if(!strncmp(get_mime($icol), "image", 5)) return $icol; // if mime is an image return

	// try /favicon.ico on host base address
	$ar = array("scheme"=>$urlparts['scheme'], "host"=>$urlparts['host'], "path"=>"/favicon.ico");
	$icol = unparse_url($ar);
	if(!strncmp(get_mime($icol), "image", 5)) return $icol; // if mime is an image return
	else return "";

}

$ur = "https://chaseonline.chase.com/logon.aspx";
$ur = "https://www.gm.com/lemon-law.html";
//$ur = "http://feeds.afterdawn.com/afterdawn?format=xml";
//$ur = "https://invest.ameritrade.com/release/images/favicon.ico";
//$ur = 'https://www.bmoharris.com/main/personal';
$ur = 'https://gearchunk.com/activate-windows-10/';
$ur = 'https://finance.yahoo.com/quote/mfc';

echo "Site = " . $ur . "<br><br>";

$st = get_page($ur);

//$finfo = new finfo(FILEINFO_MIME); echo $finfo->buffer($st);

//echo is_string($st);
/*$s = stripos( $st, 'Permalink');
$st = substr($st, ($s + 20));
for($s = 0; $s < 6; $s++)echo ord($st[$s]) . '-';
///*/
/*$st = '–ä–€ƒ–&ndash;';
//for($s = 123; $s < 256; $s++) $st = $st . chr($s) . '[' . $s . ']';
///*/

//$st = htmlentities($st, ENT_SUBSTITUTE);
/*header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
 
<head>
	<meta charset="utf-8"><!-- Your HTML file can still use UTF-8-->
</head>


<?php 

echo ' <br><br>';

//echo get_icon($ur, $st);

display_txt($st);
//echo $st;

/*echo ' <br><br>';
for($s = 0; $s < 18; $s++)echo ord($st[$s]) . '-';
echo ' <br><br>';
for($s = 0; $s < 18; $s++)echo $st[$s] . '-';
////*/

//echo $st;
/*$ur = "https://www.menards.com/_Incapsula_Resource?SWJIYLWA=5074a744e2e3d891814e9a2dace20bd4,719d34d31c8e3a6e6fffd425f7e032f3";

echo "<br><br><br><br>Site = " . $ur . "<br><br>";

$st = get_page($ur);
display_txt($st);
////*/
/*?>
<!DOCTYPE html>
 
<head>
	<title>Weather.com widgets</title>
</head>
<body>
<!---- 5 day forcast -->
<div style="background-color:ivory; overflow:hidden; width:50%; text-align:center">5 day forcast
<div id="cont_b597fc04c09d1c37d758797946dab095"><script type="text/javascript" async src="https://www.theweather.com/wid_loader/b597fc04c09d1c37d758797946dab095"></script></div>
<!---- 4 day forcast -->
<div>4 day forcast</div>
<div id="cont_c991b626ec05f950735d369b10e2d79b"><script type="text/javascript" async src="https://www.theweather.com/wid_loader/c991b626ec05f950735d369b10e2d79b"></script></div>
</div>
</body>
</html>
<?php
exit;
/*$ar=array("Volvo","BMW","Toyota");
$al = count($ar);
$a = 1;
for(; $a < $al; $al--) $ar[$al] = $ar[($al - 1)];
$ar[$a] = "Porsche";

//$ar[1] = $ar[2];
$al = count($ar);
for($x=0;$x<10;$x++)
  {
  echo $ar[$x];
  echo "<br>";
  }
exit;
////*/





/*include 'updatequote.php';
include 'curlgetpage.php';

$tick = 'pfyuyrutre';
$url = 'https://finance.yahoo.com/quote/' . $tick;
$cont = get_page($url);
preg_match("/<title[^>]*>(.*?)<\/title>/ims",$cont,$title);// get quote page for ticker
$title = strchr($title[1],"for");// remove characters before the first "for"
$title = substr($title, 4);// remove "for "
$title = str_replace(" - Yahoo Finance","",$title);// remove the end of title leaving only stock title
$title = $title . ' (' . strtoupper($tick) . ')';

$arr = getQuote($tick);
$ch = number_format($arr['close'] - $arr['prClose'], 2, '.', '');// get change
if($ch < 0) $clr = 'Red'; else $clr = 'Green'; // if < 0 color change Red otherwise Green
$change = $ch . '(' . number_format($ch/$arr['prClose']*100, 2, '.', '') . '%)';// make string of change an percent
?>
<!DOCTYPE html>
<head>
<link rel="stylesheet" href="w3.css">
<style>
th { text-align: left;}
</style>
</head>
<body>
<h3><?=$title?></h3><br>
<table style="width:50%">
  <tr>
    <th>Date</th>
    <th>High</th> 
    <th>Low</th>
    <th>Close</th>
    <th>Volume</th>
    <th>Change</th>
  </tr>
  <tr>
    <td><?=$arr['date']?></td>
    <td><?=$arr['high']?></td>
    <td><?=$arr['low']?></td>
    <td><?=$arr['close']?></td>
    <td><?=$arr['volume']?></td>
    <td style="color:<?=$clr?>;"><?=$change?> </td>
  </tr>
</table>
<?php
////*/



//// SimplePie test //////////////////////////////////////////////////////////////////////////////////////

// Make sure SimplePie is included. You may need to change this to match the location of autoloader.php
// For 1.0-1.2:
/*#require_once('../simplepie.inc');
// For 1.3+:
require_once('/var/www/php/autoloader.php');
 
// We'll process this feed with all of the default options.
$feed = new SimplePie();
 
// Set which feed to process.
//$feed->set_feed_url('https://www.npr.org/rss/rss.php');
$feed->set_feed_url('http://feeds.bbci.co.uk/news/world/rss.xml');
 
// Run SimplePie.
$feed->init();
 
// This makes sure that the content is sent to the browser as text/html and the UTF-8 character set (since we didn't change it).
//$feed->handle_content_type();
 
// Let's begin our XHTML webpage code.  The DOCTYPE is supposed to be the very first thing, so we'll keep it on the same line as the closing-PHP tag.
?>
<!DOCTYPE html>
 
<head>
	<title>Sample SimplePie Test</title>
</head>
<body>

	<div class="header">
		<h1><a href="<?php echo $feed->get_permalink(); ?>"><?php echo $feed->get_title(); ?></a></h1>
		<p><?php echo $feed->get_description(); ?></p>
	</div>
 
	<?php
	/*
	Here, we'll loop through all of the items in the feed, and $item represents the current item in the loop.
	*/
	/*foreach ($feed->get_items() as $item):
	?>
		<div class="item">
			<h2><a href="<?php echo $item->get_permalink(); ?>"><?php echo $item->get_title(); ?></a></h2>
			<p><?php echo $item->get_description(); ?></p>
			<p><small>Posted on <?php echo $item->get_date('j F Y | g:i a'); ?></small></p>

	<?php
	if ($enclosure = $item->get_enclosure())
	{	//echo 'has enclosure';
		foreach ((array) $enclosure->get_thumbnails() as $thumbnail)
		{	//echo 'has thumbnail';
			//echo $thumbnail;
			echo '<a href="' . $item->get_permalink() . '" title="' . $item->get_title() . '"><img src="' . $thumbnail . '" height="142" /></a>';
		}
	}
	?>

		</div>
	<?php endforeach; ?>
 
</body>
</html>

<?php
return;
/*
///foreach($srt as $st) echo $rows[0][$st] . ' | ';
echo '<span style="margin-right: 4em;">' . $rows[0][$srt[0]] . '</span>';
for($y = 1; $y < 5; $y++) echo '<span style="margin-right: .75em;">' . $rows[0][$srt[$y]] . '</span>';
echo "<br>";

for($x = 1; $x < $rowLen; $x++)
{	echo $rows[$x][$srt[0]] . ' ';
	for($y = 1; $y < 4; $y++) echo number_format($rows[$x][$srt[$y]], 2, '.', '') . ' ';
	echo $rows[$x][$srt[4]] . ' ';
	echo "<br>";
}
echo "Change = " . number_format(($rows[$rowLen - 1][$srt[3]] - $rows[$rowLen - 2][$srt[3]]), 2, '.', '');
//echo nl2br($data);

///*/

//echo("       now = " . $today . " - " . date("Y-m-d h:m:s a",$today) . "<br>");
//echo("5 days ago = " . $start . " - " . date("Y-m-d h:m:s a",$start) . "<br>");


/*function get_element($st, $el)
{	$s = stripos( $st, '<' . $el);// find start
	$e = stripos( $st, '</' . $el);// find end
	$str = substr($st, $e);// make a string starting with element terminator
	$e = ($e + strpos( $str, '>') + 1);// move end past > 
	return trim( substr($st, $s, ($e - $s) ) );
}

// get all elements by name. May be in any level. Element within the same element will mess this up
function get_elements($st, $el, $pn = 0)// st = buffer, el = element name, pn = partial name (0 = false)
{	$ar = array();	
	$st = str_replace('&lt;','<',$st);  $st = str_replace('&gt;','>',$st); // for some reason < or > may be &lt; or &gt; in $st
	while(true)
	{	$s = stripos( $st, '<' . $el);// find start
		//echo $s; echo "<br>";
		if($s === false) break;
		$st = substr($st, $s); // move the string to start of element
		$str = substr($st, (strlen($el) + 1), 1);// make a string containing character after element name
		if($pn == 0 && $str !== ' ' && $str !== '>')// if it is not space or > and partial name == false
		{	$st = substr( $st, strlen($el) ); // move past element name 
			continue; // continue while loop
		}
		/*if($pn)// if it is a partial name get complete name and use it for element terminator 
		{	$str = substr( $st, strpos( $st, '>') );// get the element definition with attributes
			echo '[' . $str . ']'; echo "<br>";
			$str = substr( $str, strpos( $str, ' ') );// find string up to the first space
			///// this is not done ///////
		}////*/
/*		$e = strpos( $st, '>');// get the position of the close of element definition
		if(substr($st, ($e - 1), 1) === '/')// if it is a self terminating element definition
		{	$e++;// move end past >
		}
		else
		{	$e = stripos( $st, '</' . $el);// find end
			$str = substr($st, $e);// make a string starting with element terminator
			$e = ($e + strpos( $str, '>') + 1);// move end past > 
		}

		$ar[] = trim( substr($st, 0, $e) );// save HTML element to array
		$st = substr($st, $e);// move past element
	}
	//echo count($ar); echo "<br>";
	return $ar;
}

function strip_prolog($st)
{	while(true)
	{	$f = 0;// set flag
		//$str = str_replace('<','&lt;',$st);  $str = str_replace('>','&gt;',$str); echo $str; echo "<br>"; echo "<br>";
		$s = stripos($st, '<?');// find start xml header
		//echo $s; echo "<br>";
		if($s !== false)
		{	$s = stripos($st, '?>');// find end of xml header
			$st = substr($st, ($s + 2)); // move the string past end of xml header
			$f = 1;
			//echo "got here<br>";
		}
		$s = stripos($st, '<!DOCTYPE');// find start DOCTYPE
		if($s !== false)
		{	$s = stripos($st, '>');// find end of DOCTYPE
			$st = substr($st, ($s + 1)); // move the string past end of DOCTYPE
			$f = 1;
		}
		if($f == 0) return $st;// if no matches return	
	}
}

function xml2array($st)
{	// if $st contains xml prolog go past it before sending it to this function 

	while(true)
	{	$s = stripos($st, '<');// find start
		if($s === false) break;// no < character
		$st = substr($st, ($s + 1)); // move the string past <
		$st = ltrim($st);// remove leading white space characters
		$e = strlen($st);// find end of string buffer
		for($p = 0; $p < $e; ($p++))
		{	$str = substr($st, $p, 1);// make a string containing character after element name
			if($str === ' ' || $str === '>' || $str === '/')// if it is a space or > or / it's the end of the elements name
			{	$en = substr($st, 0, $p);// get the element's name
				break;
			}
		}
		if($str === '/')
		{	if(substr($st, 0, 1) === '>') //empty element, ignore it
			{	$st = substr($st, ($p + 2)); // move the string past element name
				continue;
			}
			else
			{	// malformed xml
				echo "malformed xml<br>";
			}
		}
		// create array entry and add element name to it


		$st = substr($st, ($p + 1)); // move the string past element name
		$st = ltrim($st);// remove leading white space characters
		//echo $st; echo "<br>";
		if($str === ' ')
		{	//deal with attributes (if any) and move $st past end of element definition
		}
		if($str === '>')// end of element definition
		{
		}
		echo $en; echo "<br>"; return;
		/*{	$st = substr( $st, strlen($el) ); // move past element name 
			continue; // continue while loop
		}
		if($pn)// if it is a partial name get complete name and use it for element terminator 
		{	$str = substr( $st, strpos( $st, '>') );// get the element definition with attributes
		echo '[' . $str . ']'; echo "<br>";
			$str = substr( $str, strpos( $str, ' ') );// find the first space
		}
		$e = stripos( $st, '</' . $el);// find end
		$str = substr($st, $e);// make a string starting with element terminator
		$e = ($e + strpos( $str, '>') + 1);// move end past > 

		$ar[] = trim( substr($st, $s, $e) );// save HTML element to array
		$st = substr($st, $e);// move past element
	}
	
}///*/

/*function get_elements($st, $el)
{
	$xml = new SimpleXMLElement($st);
	//$str = $xml->channel->item[0]->asXML();
	//$str = str_replace('<','&lt;',$str);  $str = str_replace('>','&gt;',$str); echo $str; echo "<br>"; return;
	//echo $xml->channel->item[0]->title; echo "<br>"; return;
	//$result = $xml->xpath("item");
	//print_r($xml); echo "<br>";echo "<br>"; return;

	foreach ($xml->channel->item as $key => $val)
	{	echo "ITEM <br>";
		//echo "$key: $val<br>";
		foreach($val as $ke => $va)
		{	echo "$ke: $va<br>";
		}
		echo "<br>";
	}



	/*foreach ($xml as $key => $val)
	{	echo "$key: $val<br>";
		//$str = $val->asXML();
		//get_elements($str, $el);
		foreach($val as $ke => $va)
		{	echo "-----$ke: $va<br>";
			if($ke === 'item')
			{	//$str =  $val->asXML();
				//get_elements($str, $el);
				//$str = str_replace('<','&lt;',$str);  $str = str_replace('>','&gt;',$str);echo $str;
				foreach ($va as $k => $v)
				{	$st = $v; $st = str_replace('<','&lt;',$st);  $st = str_replace('>','&gt;',$st);
					echo "----------      {$k}: $st<br>";
				}
	//echo "<br>";echo "<br>";
			}
		}
	}///*/
//}


//strip_tags($st); // just display the text of HTML source

/////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////
// media images are in <img src="" <media:content or <media:thumbnails
// may not need simplepie
// split rss url into <items> and parse them for images until you find one bigger than 40 X 40 
/////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////


/*include 'functions.php';
$ur = "https://www.npr.org/rss/rss.php";
$ur = "http://feeds.bbci.co.uk/news/world/rss.xml";
$ur = "http://rss.cnn.com/rss/cnn_topstories.rss";
$ur = "http://afterdawn.com/news/afterdawn_rss.xml";
echo "Site = " . $ur . "<br>";
$st = get_page($ur);
$ar = get_elements($st, 'item');
foreach ($ar as $its)
{	//$its = str_replace('<','&lt;',$its);  $its = str_replace('>','&gt;',$its); echo $its; echo "<br>"; echo "<br>";
	$iar = get_elements($its, 'title');
	$str = $iar[0];
	$str = str_replace('<','&lt;',$str);  $str = str_replace('>','&gt;',$str); echo $str; echo "<br>";
	$iar = get_elements($its, 'img');
	foreach ($iar as $val)
	{$val = str_replace('<','&lt;',$val);  $val = str_replace('>','&gt;',$val); echo '-----' . $val; echo "<br>";}
	echo "<br>";
}
$st = strip_prolog($st); 
//xml2array($st); 
echo '<br><br>';
$st = str_replace('<','&lt;',$st);  $st = str_replace('>','&gt;',$st); echo $st;
//echo "<br>";

//echo get_title($st);

function get_title($str){
    //$str = trim(preg_replace('/\s+/', ' ', $str)); // supports line breaks inside <title>
    preg_match("/<title[^>]*>(.*?)<\/title>/ims",$str,$title);
    //preg_match("/\<title\>(.*)\<\/title\>/i",$str,$title); // ignore case
    return $title[1];
}
/*?>
<!DOCTYPE html>
<body>
<script>
function getPhp(php, params, fun)
{	if(params) params = "?" + params;
	//alert(params);
    if (window.XMLHttpRequest) xmlhttp=new XMLHttpRequest();// code for IE7+, Firefox, Chrome, Opera, Safari
    else xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");  // code for IE6, IE5
    xmlhttp.onreadystatechange=function() { if(this.readyState===4 && this.status===200){ PhpResult = this.responseText; fun();} };
    xmlhttp.open("GET",php + params,true);
    xmlhttp.send();
}

function showResult(str) {
    document.getElementById("livesearch").innerHTML="Processing '" + str + "'";
    st = new Date().getTime();
	fun = function(){ 
				tt = new Date().getTime() - st;
				if(PhpResult === '')
				{	document.getElementById("livesearch").innerHTML="Invalid url'" + str + "'";
					return;
				}
				document.getElementById("livesearch").innerHTML = "Process Time : " + tt/1000 + " Seconds";
				res = PhpResult.split("\036");
				document.getElementById('tit').value = res[0];
				document.getElementById('icn').value = res[1];
				document.getElementById('disicn').src = res[1];
				document.getElementById('des').value = res[2];
				document.getElementById('addBut').disabled = false;// turn add button on
		}; // the ajax responseText is PhpResult(cannot rename it)
	getPhp("./getbookmarkinfo.php","q=" + encodeURIComponent(str), fun);
}
</script>

  <div>
    <span class="close" onclick="myFunction('myModal')">&times;</span>
	<h3 id="BmEdHd" style="text-align:center">Bookmark</h3>
	<form action="javascript:showResult(document.getElementById('it1').value)">
	    URL<br><input type="text" size="60" id="it1" >
	    <button>Get Info</button>
	</form>
    <p><div>Title</div><input type="text" size="60" id="tit" ></p>
	<p><div>Icon</div><img id="disicn" src="icons/no-icon.ico" width="30" height="30" style="float:left"><input type="text" size="60" id="icn" ></p>
    <p><div>Description</div><textarea name="Text1" cols="70" rows="3"id="des"></textarea></p>
    <button id="addBut" onclick="" disabled >Save Bookmark</button>

    <p><div>Info area</div><div id="livesearch" style="padding: 5px;margin-top: 5px;border:1px solid #A5ACB2;">&nbsp;</div></p>
  </div>
</body>






<?php
/*$db = new SQLite3('teds');
$results = $db->query('SELECT * FROM bm4');
$frid = 4;
$or = 1;
while ($row = $results->fetchArray(SQLITE3_BOTH))
{	$ar['nm'] = $row['name'];	
	$ar['ic'] = $row['icon'];	
	$ar['ds'] = $row['description'];	
	$ar['ur'] = $row['url'];	
	$ar['fi'] = $frid;	
	$ar['ps'] = $or++;

    $sql = "INSERT INTO bm1 ('id','name','icon','description','url','frameId','order' )  VALUES (NULL, '$ar[nm]', '$ar[ic]', '$ar[ds]', '$ar[ur]', '$ar[fi]', '$ar[ps]')"; 
    if ($db->query($sql) == TRUE) {
      echo $ar[nm] . 'entry saved successfully<br>';
    }
    else {
      echo 'Error: '. $db->error;
    }

	//INSERT INTO bm1 ('id','name','icon','description','url','frameId','order' ) VALUES (NULL, $ar[nm], $ar[ic], $ar[ds], \"$ar[ur]\,\"$ar[fi]\,\"$ar[ps]\");
	//echo "";
	
	/*foreach($ar as $x => $x_value) {
    	echo "Key=" . $x . ", Value=" . $x_value;
    	echo "<br>";
	}///*/

//	$st = $row['name'];
//	echo "<script type='text/javascript'>alert('$st');</script>";
//}


<?php

function get_element($st, $el)
{	$s = stripos( $st, '<' . $el);// find start
	$e = stripos( $st, '</' . $el);// find end
	$str = substr($st, $e);// make a string starting with element terminator
	$e = ($e + strpos( $str, '>') + 1);// move end past > 
	return trim( substr($st, $s, ($e - $s) ) );
}

// get all elements by name. May be in any level. Element within the same element will mess this up
function get_elements($st, $el, $pn = 0)// st = buffer, el = element name, pn = partial name (0 = false)
{	$ar = array();	

	while(true)
	{	$s = stripos( $st, '<' . $el);// find start
		//echo $s; echo "<br>";
		if($s === false) break;
		$st = substr($st, $s); // move the string to start of element
		$str = substr($st, (strlen($el) + 1), 1);// make a string containing character after element name
		if($pn == 0 && $str !== ' ' && $str !== '>')// if it is not space or > and partial name == false
		{	$st = substr( $st, strlen($el) ); // move past element name 
			continue; // continue while loop
		}
		/*if($pn)// if it is a partial name get complete name and use it for element terminator 
		{	$str = substr( $st, strpos( $st, '>') );// get the element definition with attributes
			echo '[' . $str . ']'; echo "<br>";
			$str = substr( $str, strpos( $str, ' ') );// find string up to the first space
			///// this is not done ///////
		}////*/

		$e = strpos( $st, '>');// get the position of the close of element definition
		if(substr($st, ($e - 1), 1) === '/')// if it is a self terminating element definition
		{	$e++;// Set end past >
		}
		else
		{	$e = stripos( $st, '</' . $el);// find end
			if($e === false)// if there is no </[element name] may be an empty element
			{	// if it is not a valid HTML empty element, break 
				if(!preg_match('/(area|base|br|col|embed|hr|img|input|keygen|link|meta|param|source|track|wbr)/i', $el) ){echo $el; echo "<br>"; break;}
				$e = (strpos( $st, '>') + 1);// it is a valid empty element. Set end past >
			}
			else // found element terminator
			{	$str = substr($st, $e);// make a string starting with element terminator
				$e = ($e + strpos( $str, '>') + 1);// Set end past >
			}
		}

		$ar[] = trim( substr($st, 0, $e) );// save HTML element to array
		$st = substr($st, $e);// move past element
	}
	return $ar;
}

function strip_prolog($st)
{	while(true)
	{	$f = 0;// set flag
		//$str = str_replace('<','&lt;',$st);  $str = str_replace('>','&gt;',$str); echo $str; echo "<br>"; echo "<br>";
		$s = stripos($st, '<?');// find start xml header
		//echo $s; echo "<br>";
		if($s !== false)
		{	$s = stripos($st, '?>');// find end of xml header
			$st = substr($st, ($s + 2)); // move the string past end of xml header
			$f = 1;
			//echo "got here<br>";
		}
		$s = stripos($st, '<!DOCTYPE');// find start DOCTYPE
		if($s !== false)
		{	$s = stripos($st, '>');// find end of DOCTYPE
			$st = substr($st, ($s + 1)); // move the string past end of DOCTYPE
			$f = 1;
		}
		if($f == 0) return $st;// if no matches return	
	}
}

function xml2array($st)
{	// if $st contains xml prolog go past it before sending it to this function 

	while(true)
	{	$s = stripos($st, '<');// find start
		if($s === false) break;// no < character
		$st = substr($st, ($s + 1)); // move the string past <
		$st = ltrim($st);// remove leading white space characters
		$e = strlen($st);// find end of string buffer
		for($p = 0; $p < $e; ($p++))
		{	$str = substr($st, $p, 1);// make a string containing character after element name
			if($str === ' ' || $str === '>' || $str === '/')// if it is a space or > or / it's the end of the elements name
			{	$en = substr($st, 0, $p);// get the element's name
				break;
			}
		}
		if($str === '/')
		{	if(substr($st, 0, 1) === '>') //empty element, ignore it
			{	$st = substr($st, ($p + 2)); // move the string past element name
				continue;
			}
			else
			{	// malformed xml
				echo "malformed xml<br>";
			}
		}
		// create array entry and add element name to it


		$st = substr($st, ($p + 1)); // move the string past element name
		$st = ltrim($st);// remove leading white space characters
		//echo $st; echo "<br>";
		if($str === ' ')
		{	//deal with attributes (if any) and move $st past end of element definition
		}
		if($str === '>')// end of element definition
		{
		}
		echo $en; echo "<br>"; return;
		/*{	$st = substr( $st, strlen($el) ); // move past element name 
			continue; // continue while loop
		}
		if($pn)// if it is a partial name get complete name and use it for element terminator 
		{	$str = substr( $st, strpos( $st, '>') );// get the element definition with attributes
		echo '[' . $str . ']'; echo "<br>";
			$str = substr( $str, strpos( $str, ' ') );// find the first space
		}
		$e = stripos( $st, '</' . $el);// find end
		$str = substr($st, $e);// make a string starting with element terminator
		$e = ($e + strpos( $str, '>') + 1);// move end past > 

		$ar[] = trim( substr($st, $s, $e) );// save HTML element to array
		$st = substr($st, $e);// move past element///*/
	}
	
}

// CDATA means character data which is data that can be iterpreted as XML (like --, <, &, ', ", etc,)
// anything between <![CDATA[ and  ]] is intended as text only
function clear_CDATA($st)
{	$st = str_replace('<![CDATA[','',$st);
	$st = str_replace(']]>','',$st);
	return $st;
}

function get_attribute($el, $at)
{	$s = stripos( $el, $at . '=');// find start of attribute
	if($s === false) return '';
	$el = substr($el, ($s + strlen($at) + 1) ); // move the string to start of attribute before quote

	// find what is used for quote mark and move string past it(may be " or ')
	$qt = '"'; // set quote
	$s = stripos( $el, $qt);// check for "
	if($s === false)
	{	$qt = "'"; // set quote
		$s = stripos( $el, $qt);// check for '
		if($s === false) return '';
	}
	$el = substr($el, ($s + 1) ); // move the string to start of attribute

	$s = stripos( $el, $qt);// find end of attribute
	$el = substr($el, 0, $s);// end string there
	return $el;

}

// get images from rss element
function get_images($el)
{	$ar = array();
	// check for img tags
	$ar2 = get_elements($el, 'img');
	foreach ($ar2 as $val)
	{	$st = get_attribute($val, "src");
		if($st !== '') $ar[] = $st;	
		//echo '----- '; display_txt($val); echo "<br>";
	}//**/
	// check for media:content tags
	$ar2 = get_elements($el, 'media:content');
	foreach ($ar2 as $val)
	{	$st = get_attribute($val, "url");
		if($st !== '') $ar[] = $st;	
	}
	// check for media:thumbnail tags
	$ar2 = get_elements($el, 'media:thumbnail');
	foreach ($ar2 as $val)
	{	$st = get_attribute($val, "url");
		if($st !== '') $ar[] = $st;	
	}
	// check for enclosure tags
	$ar2 = get_elements($el, 'enclosure');
	foreach ($ar2 as $val)
	{	$st = get_attribute($val, "url");
		if($st !== '') $ar[] = $st;	
	}
	return $ar;	
} 

/////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////
// media images for articles are in <img src="" <media:content url="" or <media:thumbnails
// split rss url into <item>s or <entry>s and parse them for images until you find one bigger than 40 X 40 
//
// newsfeed icon and title is usually in <image> tag before first article. icon is in <url> title is in <title>
// 
/////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////

function display_txt($t)// temporary for debugging
{	$t = str_replace('<','&lt;',$t);  $t = str_replace('>','&gt;',$t); echo $t;
}

include 'functions.php';
$ur = "http://weblog.philringnalda.com/feed/";// no pictures, uses entry instead of item
$ur = "http://www.flickr.com/services/feeds/photos_public.gne?format=rss2";// img src=, media:content url=, media:thumbnail url=, enclosure url=, time -07:00
$ur = "http://www.reddit.com/.rss";// img, uses entry instead of item, uses &quot; for quote
$ur = "http://news.google.com/?output=rss";//  img (HTML empty element, terminated with > instead of />)
$ur = "http://osnews.com/files/recent.rdf";// no pictures, no time
$ur = "http://rss.cnn.com/rss/cnn_topstories.rss";// media:content, title in <title><![CDATA[   ]]></title>
$ur = "http://feeds.feedburner.com/web20Show";// media:content, first image in all is a 96X96 icon. Some have a real 2nd image
$ur = "http://afterdawn.com/news/afterdawn_rss.xml";// img
$ur = "https://www.huffingtonpost.com/section/world-news/feed";// enclosure url=, eastern time
$ur = "http://feeds.bbci.co.uk/news/world/rss.xml";// media:thumbnail, title in <title><![CDATA[   ]]></title>
$ur = "https://www.npr.org/rss/rss.php";// img, eastern time
$ur = "http://rss.nytimes.com/services/xml/rss/nyt/HomePage.xml";// media:content url=
$ur = "http://www.reddit.com/.rss";// img, uses entry instead of item, uses &quot; for quote
//$ur = "http://feeds.reuters.com/reuters/topNews";
//$ur = "http://feeds.reuters.com/Reuters/domesticNews";
//$ur = "http://rssfeeds.usatoday.com/usatoday-NewsTopStories";
//$ur = "";
//$ur = "http://www.nasa.gov/rss/image_of_the_day.rss";
//$ur = "http://www.pbs.org/wgbh/nova/rss/nova.xml";
//$ur = "http://feeds.sciencedaily.com/sciencedaily";
//$ur = "http://feeds.bbci.co.uk/news/rss.xml?edition=us";
//$ur = "";
//$ur = "";
//$ur = "";
//$ur = "";
//$ur = "";
//$ur = "https://www.theguardian.com/us-news/rss";// media:content url=

?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="w3.css">
	<title>News Feed Test</title>
</head>
<body>
<?php

echo "Site = " . $ur . "<br><br>";
$st = get_page($ur);
$st = html_entity_decode($st);// replace all HTML special characters(&lt; &gt; &quot; etc.) which will mess up several functions

$ar = get_elements($st, 'item');
if(count($ar) == 0) $ar = get_elements($st, 'entry');
foreach ($ar as $its)
{
	// get date (may be able to parse it with date_parse() and use [relative] => Array to convert to local time)
	$iar = get_elements($its, 'updated');
	$upd = strip_tags($iar[0]);
	if(empty($upd)){$iar = get_elements($its, 'pubDate'); $upd = strip_tags($iar[0]);}

	echo 'ARTICLE Updated: ' . $upd;	echo "<br>";

	$iar = get_elements($its, 'title');	$tit = strip_tags(clear_CDATA($iar[0]));// get title (see clear_CDATA function for explanation)
	$iar = get_elements($its, 'description'); $des = strip_tags(clear_CDATA($iar[0]));// get description

	// get link to article
	$iar = get_elements($its, 'link');
	$lnk = strip_tags($iar[0]);
	if(empty($lnk)) $lnk = get_attribute($iar[0], 'href');

	echo '<div style="height:120px; overflow: hidden; background-color:ivory;" ><a href="' . $lnk . '" style="text-decoration:none" target="_blank">';

	// extract images from img element
	$iar = get_images($its); // not done
	foreach ( array_reverse($iar) as $val)
	{	if($val[0] == '/')// see if url starts with /
		{	if($val[1] == '/')// if url starts with // prepend http:
			{	$val = "http:" . $val;
			}
			else
			{// prepend base of site to url - NOT DONE
			}
		}
		list($wid, $hgt) = getimagesize($val);// 
		if($wid > 40 && $hgt > 40)
		{	echo '<img src="' . $val . '" style="float:left" height="120" >';
			break;
		}
	}
	echo "<b>$tit</b><br>$des</a>";
	echo "</div>";
	echo "<br>";
}
//$st = strip_prolog($st); 
//xml2array($st); 
echo '<br><br>'; display_txt($st);
//echo "<br>";
?>
</body>
</html>
<?php

//echo get_title($st);

function get_title($str){
    //$str = trim(preg_replace('/\s+/', ' ', $str)); // supports line breaks inside <title>
    preg_match("/<title[^>]*>(.*?)<\/title>/ims",$str,$title);
    //preg_match("/\<title\>(.*)\<\/title\>/i",$str,$title); // ignore case
    return $title[1];
}

/*function get_elements($st, $el)
{
	$xml = new SimpleXMLElement($st);
	//$str = $xml->channel->item[0]->asXML();
	//$str = str_replace('<','&lt;',$str);  $str = str_replace('>','&gt;',$str); echo $str; echo "<br>"; return;
	//echo $xml->channel->item[0]->title; echo "<br>"; return;
	//$result = $xml->xpath("item");
	//print_r($xml); echo "<br>";echo "<br>"; return;

	foreach ($xml->channel->item as $key => $val)
	{	echo "ITEM <br>";
		//echo "$key: $val<br>";
		foreach($val as $ke => $va)
		{	echo "$ke: $va<br>";
		}
		echo "<br>";
	}



	/*foreach ($xml as $key => $val)
	{	echo "$key: $val<br>";
		//$str = $val->asXML();
		//get_elements($str, $el);
		foreach($val as $ke => $va)
		{	echo "-----$ke: $va<br>";
			if($ke === 'item')
			{	//$str =  $val->asXML();
				//get_elements($str, $el);
				//$str = str_replace('<','&lt;',$str);  $str = str_replace('>','&gt;',$str);echo $str;
				foreach ($va as $k => $v)
				{	$st = $v; $st = str_replace('<','&lt;',$st);  $st = str_replace('>','&gt;',$st);
					echo "----------      {$k}: $st<br>";
				}
	//echo "<br>";echo "<br>";
			}
		}
	}///*/
//}



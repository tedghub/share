<?php

$db = new SQLite3('teds');

// Get the database id of element.
$entryId = (int) substr($_GET["id"], 2);
// Get the container frame id elements parent div id (bm?? for bookmark) bm = bookmark ?? = frame id. For frame just id. 
$parentId = $_GET["pid"];
// Get new position of entry
$newPos = $_GET["pos"];

if( substr($parentId, 0, 3) == "col"){ // entry is a frame
	$tb = "frames";
	$parentId = (int) substr($parentId, 3); // get parent frame integer id from element id text
	// Change entry's column to $parentId
	$db->exec('UPDATE frames Set column=' . $parentId . ' where id=' . $entryId );
	$ret = $db->query('SELECT id From frames where column=' . $parentId . ' ORDER by pos');
}
else{
	if( substr($parentId, 0, 2) == "bm") $tb = "bookmarks"; // entry is a bookmark
	if( substr($parentId, 0, 2) == "sq") $tb = "quotes"; // entry is a quote

	$parentId = (int) substr($parentId, 2); // get parent frame integer id from element id text
	// Change entry's frameId to $parentId
	$db->exec('UPDATE ' . $tb . ' Set frameId=' . $parentId . ' where id=' . $entryId );
	$ret = $db->query('SELECT id From ' . $tb . ' where frameId=' . $parentId . ' ORDER by pos');
}

$pos = 0;

while($row = $ret->fetchArray(SQLITE3_ASSOC) ) {
	if($pos == $newPos) $pos++; // this is where $entryId goes so don't set any other bm to it 
  	if($row['id'] == $entryId){ // set $entryId pos to $newPos and fetch next bm without incrementing $pos
  		$db->exec('UPDATE ' . $tb . ' Set pos=' . $newPos . ' where id=' . $row['id']);
  		continue;
  	}
	$db->exec('UPDATE ' . $tb . ' Set pos=' . $pos . ' where id=' . $row['id']);
 	$pos++;
 }
 

<?php
$db = new SQLite3('teds');
$results = $db->query('SELECT * FROM bookmarks WHERE id=' . $_GET["q"]);
$row = $results->fetchArray(SQLITE3_BOTH);
echo $row['url'];
echo "\036";
echo $row['name'];
echo "\036";
echo $row['icon'];
echo "\036";
echo $row['description'];


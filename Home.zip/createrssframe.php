<?php
include 'functions.php';

$db = new SQLite3('teds');

$st = str_replace('"','""',$_GET['t']);// fix title " characters for INSERT INTO

// set position to highest position number in column + 1
$results = $db->query('SELECT MAX(pos) AS max_pos FROM frames WHERE column = ' . $_GET['c']);// get highest position number in column
$row = $results->fetchArray(SQLITE3_BOTH);
$po = $row["max_pos"] + 1;

// set frame id to highest id in frames + 1
$results = $db->query('SELECT MAX(id) AS max_id FROM frames');// get highest id in frames
$row = $results->fetchArray(SQLITE3_BOTH);
$fid = $row["max_id"] + 1;

// insert frame in sql frames table
$db->exec('INSERT INTO frames (id,type,title,contents,column,pos) VALUES (' . $fid . ',"nf","' . $st . '","' . $_GET['con'] . '",' . $_GET['c'] . ',' . $po . ')');

displayFrame($fid, "nf", $_GET['t'], $_GET['con']);


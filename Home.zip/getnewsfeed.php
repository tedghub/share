<?php

include 'functions.php';

$st = get_page($_GET["url"]);
//$st = preg_replace('/[[:^print:]]/', '', $st);// replace all unprintable characters

$ar =  get_articles($st);
$ar[] = $_GET["id"];// get feed id from ajax then add it to the end of the array for java to use and remove from array
echo json_encode($ar, JSON_PARTIAL_OUTPUT_ON_ERROR);// encode php array to JSON array and send it


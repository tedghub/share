<?php
$myVar = "hello world!";

var_dump($myVar);
?>

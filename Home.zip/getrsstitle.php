<?php

include 'functions.php';

$st = get_page($_GET["q"]);
$ar = get_elements($st, 'image');

foreach ($ar as $its) // go through image tags until you find one with a title element
{	$tar = get_elements($its, 'title');
	$ts = strip_tags($tar[0]);
	if(!empty($ts)) break; 
}

if(empty($ts)) // if still no title find title tag before first article
{	$e = stripos( $st, '<entry');// find first entry tag
	if ($e === false) $e = stripos( $st, '<item');// if no entry find first item tag
	if ($e === false) $ts = 'Not a valid rss';// if no item it's not a valid rss
	else
	{	$ts = substr($st, 0, $e); // get buffer up to first article
		$tar = get_elements($ts, 'title');
		$ts = strip_tags($tar[0]);
		if(empty($ts)) $ts = 'No title'; // no title make title = No title
	}	
}

echo $ts;


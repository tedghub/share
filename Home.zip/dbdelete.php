<?php
$db = new SQLite3('teds');
$db->query('DELETE FROM ' . $_GET['tb'] . ' WHERE id=' . $_GET['id']);


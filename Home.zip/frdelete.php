<?php
$db = new SQLite3('teds');
$fr = $_GET['id'];
$frametype = $db->querySingle('SELECT type FROM frames WHERE id=' . $fr);
if($frametype === "bm") $db->query('DELETE FROM bookmarks WHERE frameId=' . $fr);
if($frametype === "sq") $db->query('DELETE FROM quotes WHERE frameId=' . $fr);
$db->query('DELETE FROM frames WHERE id=' . $fr);


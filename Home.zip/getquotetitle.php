<?php
include 'functions.php';

echo getQuoteDescription($_GET["tick"]);


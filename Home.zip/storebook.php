<?php
include 'functions.php';
//include 'curlgetpage.php';

$db = new SQLite3('teds');

//class TedDB extends SQLite3{ function __construct(){ $this->open('teds');} }
$st = str_replace('"','""',$_GET['q']);
$arr = explode("\036", $st);

if($arr[2])// find icon
{	$img = get_page($arr[2]);

	if(strlen($img))// if $arr[2] was a valid url 
	{	$urlparts = parse_url($arr[2]);
		$ico = "icons/" . $urlparts['host'] . str_replace("/","_",$urlparts['path']); // create custom name for icons directory
		file_put_contents($ico, $img);
	}
	else // see if it is a local file
	{	$img = file_get_contents($arr[2]);
		$finfo = new finfo(FILEINFO_MIME);// used to check mime
		if( !strncmp( $finfo->buffer($img), "image", 5)  ) $ico = $arr[2];// if it is valid image, assign it to ico
		else $ico = "icons/no-icon.ico";
	}
}
else $ico = "icons/no-icon.ico";

$st = substr($arr[4], 2); // get frame id

// get next position number
$results = $db->query('SELECT MAX(pos) AS max_pos FROM bookmarks WHERE frameId = ' . $st);
$row = $results->fetchArray(SQLITE3_BOTH);
$or =  $row["max_pos"] + 1;

$sql = "INSERT INTO bookmarks ('id','name','icon','description','url',frameId,pos) VALUES (NULL,\"$arr[1]\",\"$ico\",\"$arr[3]\",\"$arr[0]\",$st,$or)";
$db->exec($sql);
$db->close();
displayBookmarks($st);

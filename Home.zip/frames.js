
function dispNewFrameDia()// display new framedialog
{	document.getElementById("nfTit").value = ''; // clear frame dialog title
	myFunction('crFrModal');// display dialog
}

function rcFrame(event, id)// frame context menu. event = mouse event id = the frame's id
{	// set onclick functions in frame context menu
	el = event.target.parentNode;// get element parent
	// find parent right under column
	while(el.parentNode.className.split(' ').indexOf('w3-col')==-1) el = el.parentNode;
	document.getElementById('rcfd').onclick = function() {frdelete(id, el); myFunction('rcFrModal');}// delete frame and close dialog
	document.getElementById('rcfmu').onclick = function() {moveFr(id, el, -1);}
	document.getElementById('rcfmd').onclick = function() {moveFr(id, el, 1);}
	document.getElementById('rcfcn').onclick = function() {moveFr(id, el, 0);}
	document.getElementById('rcfed').onclick = function() {rnFrameDia(id, el);}
	myFunction('rcFrModal');// open dialog
	locatePopup('rcFrCont', event); // position it relative to cursor and in window
}

function rnFrameDia(id, el)// run rename frame dialog. id = the frame's id, el = frames html element 
{	myFunction('rcFrModal');// close frame rightclick dialog
	document.getElementById('frNmIn').value = el.getElementsByTagName("P")[0].innerText;// set rename frame dialog input text to the current frame name

	// open frame name dialog
	var rect = el.getBoundingClientRect();// get frames rectangle coordinates
	diEl = document.getElementById('rnFrModal').firstElementChild;// get rename frame dialog element
	diEl.firstElementChild.onsubmit = function() {rnFrame(id, el);}//(" + id + ", '" + el +"');";
	myFunction('rnFrModal');// show modal dialog
	diEl.style.left = el.offsetLeft +"px"; // set x position of rename frame dialog element
	// Adjust rename frame dialog y position to fit it on the window
	if((diEl.clientHeight + rect.top) > window.innerHeight) diEl.style.top = window.innerHeight - diEl.clientHeight +"px";
	else diEl.style.top = rect.top +"px";
}

function rnFrame(id, el)// rename frame. id = the frame's id, el = frames html element 
{	// change name on web page
	el.getElementsByTagName("B")[0].innerHTML = document.getElementById('frNmIn').value;
	// change name in database
	fun = function() { myFunction('rnFrModal');}; // the ajax callback function closes dialog
	getPhp("./renameframe.php","f=" + id + "&t=" + encodeURIComponent(document.getElementById('frNmIn').value), fun);///*/
}

function moveFr(id, el, dir)// id = sql table's bookmark id, el = html element dir = direction(-1 = up 1 = down)
{	// move item in database
	fun = function() { myFunction('rcFrModal');}; // the ajax callback function closes dialog
	getPhp("./moveframe.php","id=" + id + "&dr=" + dir, fun);///*/

	// move item on web page
	if(dir == -1) el.parentNode.insertBefore(el, el.previousElementSibling);//direction is up. If there is a previous element put it before it, if not it will go to end of list
	else if(dir == 1)// direction is down
	{	if(el.nextElementSibling) el.parentNode.insertBefore(el, el.nextElementSibling.nextElementSibling);// if it is not last element move it down
		else el.parentNode.insertBefore(el, el.parentNode.firstElementChild);// if it is last element move to top of list 
	}
	else // direction is next column (dir == 0)
	{	col = el.parentNode.id[3]; // get column number
		if( col >= 2 ) col = 1; else col++;
		ce = document.getElementById('col' + col); // get next colunmn
		ce.insertBefore(el, ce.firstElementChild); // insert element as first item in next column
	}
}

// Create a new frame from parameters in New frame Modal
function createFr()
{	col = document.getElementById("nfCol").value;// get column number from dialog
	if(col > 2) col = 2;	
	fr = document.createElement("DIV");// create a div to contain frame
	tit = document.getElementById("nfTit").value; // get the title from dialog

	// get which radio button is checked and assign frame type (ty) from it's value
	tys = document.getElementById("nfTyps").getElementsByTagName('INPUT');
	for(i = 0; i < tys.length; i++){  if (tys[i].type === 'radio' && tys[i].checked) { ty = tys[i].value; break;} }

	if(ty === "nf")// if it is a news feed run create news frame dialog
	{	myFunction('crFrModal'); // close create frame dialog
		document.getElementById('edNfUrl').value = ''; // clear url value in dialog
		document.getElementById('edNtTit').value = tit;// set dialog title
		myFunction('edNfModal');// run create news frame dialog
	}
	else // add other types of frames
	{	if(tit == null || tit.trim() === "") tit = ty;// if there is no title make it frame type
	
		// fill frame and close dialog
		fun = function() { fr.outerHTML = PhpResult; myFunction('crFrModal'); };
		getPhp("./createframe.php","t=" + tit + "&ty=" + ty + "&c=" + col, fun);

		document.getElementById("col" + col).appendChild(fr);// append frame to column on webpage
	}
}


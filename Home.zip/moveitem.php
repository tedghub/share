<?php

$db = new SQLite3('teds');

$tb = $_GET["tb"]; // get name of the table

// get frame id and position
$results = $db->query('SELECT pos, frameId From ' . $tb . ' where id=' . $_GET["id"]);
$row = $results->fetchArray(SQLITE3_BOTH);
$pos = $row[0];
$fid = $row[1];

if($_GET["dr"] == -1) // if direction is up
{	// find row with previous position if there is one
	$results = $db->query('SELECT * FROM ' . $tb . ' where frameId=' . $fid . ' AND pos<' . $pos . ' ORDER BY pos DESC LIMIT 1');
	$row = $results->fetchArray(SQLITE3_BOTH);
	if($row) // if there is a previous position swap positions 
	{	$db->exec('UPDATE ' . $tb . ' Set pos=' . $pos . ' where id=' . $row['id']);// set previous rows position to current rows position
		$db->exec('UPDATE ' . $tb . ' Set pos=' . $row['pos'] . ' where id=' . $_GET["id"]);// set current rows position to previous rows position
	}
	else // there is no previous position set position to last position in frame
	{	$results = $db->query('SELECT MAX(pos) AS max_pos FROM ' . $tb . ' WHERE frameId = ' . $fid);// get highest position number in frame
		$row = $results->fetchArray(SQLITE3_BOTH);
		$db->exec('UPDATE ' . $tb . ' Set pos=' . ($row["max_pos"] + 1) . ' where id=' . $_GET["id"]);// set current to 1 higher
	}
}
else // direction is down
{	// find row with next position if there is one
	$results = $db->query('SELECT * FROM ' . $tb . ' where frameId=' . $fid . ' AND pos>' . $pos . ' ORDER BY pos LIMIT 1');
	$row = $results->fetchArray(SQLITE3_BOTH);
	if($row) // if there is a next position swap positions 
	{	$db->exec('UPDATE ' . $tb . ' Set pos=' . $pos . ' where id=' . $row['id']);// set next rows position to current rows position
		$db->exec('UPDATE ' . $tb . ' Set pos=' . $row['pos'] . ' where id=' . $_GET["id"]);// set current rows position to next rows position
	}
	else // there is no next position set position to first position
	{	// get first position of frame
		$results = $db->query('SELECT MIN(pos) AS min_pos FROM ' . $tb . ' WHERE frameId = ' . $fid);
		$row = $results->fetchArray(SQLITE3_BOTH);
		if($row["min_pos"] > 1)// if first position is greater than 1 set current row position to 1 less
		{	$db->exec('UPDATE ' . $tb . ' Set pos=' . ($row["min_pos"] - 1) . ' where id=' . $_GET["id"]);
		}
		else //first position is 1. Reorder entire frame and set current row to first position
		{	$db->exec('UPDATE ' . $tb . ' Set pos=pos+1 where frameId = ' . $fid); // increment all positions
			$db->exec('UPDATE ' . $tb . ' Set pos=1 where id=' . $_GET["id"]);// set current row position to 1 
		}
	}
}


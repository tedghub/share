
var rssFeeds = new Object; // create an object to contain news feeds

function hoverdiv(e,divid)// can not have popup cover mouse cursor or a mouseout event will be triggered
{	var x  = e.clientX + 20; var y  = e.clientY + 20; // get mouse coordinates and add 20 pxs
	var w = window.innerWidth;  var h = window.innerHeight;// get current window dimensions

	var div = document.getElementById(divid);
	if(div.style.display === 'inline') alert('second hover');
	div.style.display = 'inline';// display popup(must be displayed before you can get info from it)

	// adjust x position to fit on page if needed
	var cw = div.clientWidth; // get element width
	var xl =  w - cw; // get the max x coor to keep it on page  
	if(x > xl) x -= cw + 40;// if it is off page on right side move it to -20 px left side of cursor
	div.style.left = x + "px";

	// adjust y position to fit on page if needed
	var ch = div.clientHeight; // get element height
	var yl =  h - ch; // get the max y coor to keep it on page 
	if(y > yl) y -= ch + 40; // if it is off page on bottom move it to -20 px from top of cursor
	if(y < 0) y = 0; // if popup height will not fit above or below cursor move it to top of page
	div.style.top = y + "px";

	return false;
}

// create a how long ago string from a date string
function getAgoStr(ds)// ds = date string
{	dt = new Date(ds);
	nw = new Date();
	ms = dt.getTime();
	if(ms > 0)
	{	dif = nw.getTime() - ms;
		dif = dif/60000;
		if(dif > 59)
		{	dif = dif / 60;
			if(dif > 23){ dif = dif / 24; ago = '(' + Math.round(dif) + ' days ago' + ')';}
			else ago = '(' + Math.round(dif) + ' hours ago' + ')';
		}
		else ago = '(' + Math.round(dif) + ' minutes ago' + ')';
	}
	else ago = '(No date in feed)';
	return ago;
}

// create a popup window to display whole article
function makeRssPopup(ar, id)// ar = array holding articles, id = popup id (composit of index for array and frame id)
{	idx = parseInt(id);// retrieve index from popup id
	st = '<div id="' + id + '" style="overflow: hidden; background-color:white; width:30%; display:none; position:fixed;';
		st += ' padding:10px; border: 1px solid lightgrey;" >';
	st += '<img src="' + ar[idx].image + '" style="float:left" height="' + sz + '" >';
	st += '<b>' + ar[idx].title + '</b><br>';
	st += '<span style="white-space:nowrap; font-size: 90%; margin: 0 .2em">' + ago + '</span>';
	st += ar[idx].desc;
	st += '</div>';
	return st;
}

// display news feed
function displayRss(id, os)// id = newsfeed container id, os = array offset of first article to display
{	ar = rssFeeds[id];
	al = ar.length;

	if(os >= al) os = 0; // if os is beyond array length make it 0
	if(os < 0) os = Math.floor((al - 1) / 10) * 10; // if os is less than 0 make it the last page

	sz = 70;// height of article div

	st = '';

	for(a = os; a < al && a < (os + 3); a++)//display in full first 3 articles
	{	ago = getAgoStr((ar[a].date).date);// create a how long ago string from a date string 
		puid = a + id;// create an unique id for popup window with index prepended to frame id

		// create html
		st += '<div style="height:' + sz + 'px; overflow: hidden;" >';
		st += '<div style="display:inline" class="ul_hover">';// have to put link (<a) in a div to undeline on hover(doesn't work for <a)  
		st += '<a onmouseover="RssHov = setTimeout(function(){hoverdiv(event,\'' + puid + '\'); }, 500)" onmouseout="hide(\'' + puid + '\'); clearTimeout(RssHov);" href="' + ar[a].link + '"';
			st += 'style="text-decoration:none" target="_blank">';
		st += '<img src="' + ar[a].image + '" style="float:left" height="' + sz + '" >';
		st += '<b>' + ar[a].title + '</b>';
		st += '<span style="white-space:nowrap; font-size: 90%; margin: 0 .2em">' + ago + '</span>';
		st += ar[a].desc;
		st += '</a></div></div><br>';
		st += makeRssPopup(ar, puid); // create popup window
	}

	for(; a < al && a < (os + 10); a++)// display titles of next 7 articles
	{	ago = getAgoStr((ar[a].date).date);
		puid = a + id;
		st += '<div style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" >';
		st += '<div style="display: inline" class="ul_hover">';
		st += '<a onmouseover="RssHov = setTimeout(function(){hoverdiv(event,\'' + puid + '\'); }, 500)" onmouseout="hide(\'' + puid + '\'); clearTimeout(RssHov);" href="' + ar[a].link + '"';
			st += 'style="text-decoration:none" target="_blank">>' + ar[a].title;
		st += '</a></div><br></div>';
		st += makeRssPopup(ar, puid); // create popup window
	}

	// add previous and next buttons to bottom of frame
	st += '<br>';
	st += '<div style="justify-content:center; display:flex;">';
	st += '<button style="border:none; background:none;" onclick="displayRss(\'' + id + '\', ' + (os - 10) + ');"><</button>';
	st += '<span style="margin: 0px 20px;">' + (os / 10 +  1) + ' of ' + Math.ceil(al / 10) + '</span>';
	st += '<button style="border:none; background:none;" onclick="displayRss(\'' + id + '\', ' + (os + 10) + ')">></button></div>';

	document.getElementById(id).innerHTML = st;
}

function getRssTit(url)
{	fun = function() { document.getElementById('edNtTit').value = PhpResult;}; // the ajax responseText is PhpResult(cannot rename it)
	getPhp("./getrsstitle.php","q=" + encodeURIComponent(url), fun);
}

function createRssFr(url, tit)
{	col = document.getElementById("nfCol").value;// get column number from new frame dialog
	if(col > 2) col = 2;	
	fr = document.createElement("DIV");// create a div to contain frame

	fun = function() // fill frame, close dialog and run scripts
	{	fr.innerHTML = PhpResult;
		myFunction('edNfModal');
		eval(fr.getElementsByTagName("script")[0].innerHTML); // execute the newsfeed update script
	};
	getPhp("./createrssframe.php","t=" + tit + "&con=" + url + "&c=" + col, fun);

	document.getElementById("col" + col).appendChild(fr);// append frame to column on webpage
}

function updateRss(id, url)
{	fun = function()
	{	res = JSON.parse(PhpResult);// parse JSON array into java array of objects
		rid = res.pop();// pop newsfeed container id from end of the array(added in php)
		rssFeeds[rid] = res;// add newsfeed to newsfeeds object as newsfeed container id
		displayRss(rid, 0);// display first page
	};
	getPhp('getnewsfeed.php','id=' + id + '&url=' + url, fun);
}


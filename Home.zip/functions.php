<?php

///////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////// miscellaneous functions /////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////

function get_page($url) {
    //fopen("cookies.txt", "w");
    $parts = parse_url($url);
    if(isset($parts['host'])) $host = $parts['host']; else $host = '';
    $ch = curl_init();

    $header = array('GET /1575051 HTTP/1.1',
        "Host: {$host}",
        'Accept:text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
		'Accept: application/atom+xml, application/rss+xml, application/rdf+xml;q=0.9, application/xml;q=0.8, text/xml;q=0.8, text/html;q=0.7, unknown/unknown;q=0.1, application/unknown;q=0.1, */*;q=0.1',
        'Accept-Language:en-US,en;q=0.8',
        'Cache-Control:max-age=0',
        'Connection:keep-alive',
        'Host:adfoc.us',
        'User-Agent:Mozilla/5.0 (X11; Linux x86_64; rv:52.0) Gecko/20100101 Firefox/52.0',
    );

	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_REFERER, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
	curl_setopt($ch, CURLOPT_TIMEOUT, 15);

    curl_setopt($ch, CURLOPT_COOKIESESSION, true);
    curl_setopt($ch, CURLOPT_COOKIEFILE, 'cookies.txt');
    curl_setopt($ch, CURLOPT_COOKIEJAR, 'cookies.txt');
    curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
    //$data = curl_exec($ch);
    $data = curl_exec_utf8($ch);
    curl_close($ch);

    return $data;
}

/** The same as curl_exec except tries its best to convert the output to utf8 **/
function curl_exec_utf8($ch)
{    $data = curl_exec($ch);

    //if (!is_string($data)) return $data; //////// This is always shows data as string even for icons. /////////

    unset($charset);
    $content_type = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);

    /* 1: HTTP Content-Type: header */
    preg_match( '@([\w/+]+)(;\s*charset=(\S+))?@i', $content_type, $matches );
    if ( isset( $matches[3] ) )
        $charset = $matches[3];

    /* 2: <meta> element in the page */
    if (!isset($charset)) {
        preg_match( '@<meta\s+http-equiv="Content-Type"\s+content="([\w/]+)(;\s*charset=([^\s"]+))?@i', $data, $matches );
        if ( isset( $matches[3] ) ) {
            $charset = $matches[3];
            /* In case we want do do further processing downstream: */
            $data = preg_replace('@(<meta\s+http-equiv="Content-Type"\s+content="[\w/]+\s*;\s*charset=)([^\s"]+)@i', '$1utf-8', $data, 1);
        }
    }

    /* 3: <xml> element in the page */
    if (!isset($charset)) {
        preg_match( '@<\?xml.+encoding="([^\s"]+)@si', $data, $matches );
        if ( isset( $matches[1] ) ) {
            $charset = $matches[1];
            /* In case we want do do further processing downstream: */
            $data = preg_replace('@(<\?xml.+encoding=")([^\s"]+)@si', '$1utf-8', $data, 1);
        }
    }

    /* 4: PHP's heuristic detection */ ////// this causes errors for certain urls !!!!! ////////
    /*if (!isset($charset)) {
        $encoding = mb_detect_encoding($data);
        if ($encoding)
            $charset = $encoding;
    }///*/

    /* 5: Default for HTML */
    if (!isset($charset)) {
        if (strstr($content_type, "text/html") === 0)
            $charset = "ISO 8859-1";
    }

    /* Convert it if it is anything but UTF-8 */
    /* You can change "UTF-8"  to "UTF-8//IGNORE" to 
       ignore conversion errors and still output something reasonable */
    if (isset($charset) && strtoupper($charset) != "UTF-8")
        $data = iconv($charset, 'UTF-8', $data);

    return $data;
}

function displayFrame($fid, $typ, $tit, $con)
{	// start header
	?>
	<div class="w3-margin-top w3-container w3-white" onmousedown="mouseDownHandler(event,this.parentNode)" oncontextmenu="rcFrame(event, <?=$fid?>); return false;">
	<?php
	
	if($typ === "bm")
	{	$id = $typ . $fid;// create id for bookmarks
		$oc = "addBookmark('" . $id . "')";// create onclick response
		?>
			<p style="float:left"><img src="./icons/bookmark.png" height='20' style="margin-right:.2em"><b><?=$tit?></b></p>
	    	<button title="Add Bookmark" style="border:none; background:none; padding:8; float:right;" onclick="<?=$oc?>"><p>+</p></button>
	   		
	  	</div>
		<div class="w3-container w3-white">
			<div id="<?=$id?>" class="bmtarget" style="min-height: 5px">
				<?php displayBookmarks($fid); ?>
			</div>
		</div>
		<?php
	}
	if($typ === "nt")
	{	$id = "nt" . $fid;// create id for notes
		// the nl2br() function converts new line characters to <br> for proper display in html
		?>
			<p style="float:left"><img src="./icons/notes.png" height='20' style="margin-right:.2em"><b><?=$tit?></b></p>
	    	<div id="ntsv<?=$fid?>" class="w3-hide" title="Save" style="margin-top: 10px; padding:8; float:right;">
				<button onclick="saveNote(<?=$fid?>, <?=$id?>)">Save</button>
				<button onclick="noteCancel(<?=$fid?>)">Cancel</button>
			</div>
		</div>
	  	<div class="w3-container w3-white">
			<p contenteditable="true" style="margin-top: 0px; min-height:2em;" onfocus="noteFocus(<?=$fid?>)" oninput="noteChange('<?=$fid?>');" onkeydown="ntKeyDown(event)" id="<?=$id?>"><?=$con?></p>
		</div>
		<?php
	}
	if($typ === "sq")
	{	$id = $typ . $fid;// create id for stock quotes
		$oc = "addQuote('" . $id . "')";// create onclick response
		?>
			<p style="float:left"><img src="./icons/money.png" height='20' style="margin-right:.2em"><b><?=$tit?></b></p>
	    	<button title="Add Quote" style="border:none; background:none; padding:8; float:right;" onclick="<?=$oc?>"><p>+</p></button>
	   		
	  	</div>
		<div class="w3-container w3-white">
			<div id="<?=$id?>" style="overflow: hidden;">
				<?php displayQuotes($fid, $typ); ?>
			</div>
		</div>
		<?php
	}
	if($typ === "nf")
	{	$id = "nf" . $fid;// create id for newsfeed container
		?>
			<p style="float:left" title="<?=$con?>"><img src="./icons/rss.png" height='20' style="margin-right:.2em"><b><?=$tit?></b></p>
		</div>
	  	<div class="w3-container w3-white">
			<div id="<?=$id?>" style="overflow: hidden;">
				<script>updateRss("<?=$id?>", "<?=$con?>");</script>
				...loading...
			</div>
		</div>
		<?php
	}
}

function get_mime($url)
{	$buf = get_page($url);
	$finfo = new finfo(FILEINFO_MIME);
	return $finfo->buffer($buf);
}

function checkurl($st)// check if $st is a valid url NOT DONE OR USED
{	$buf = get_page($st);
	$ar = get_elements($buf, 'head');
	if(count($ar) == 0) return false;
	$ar = get_elements($ar[0], 'title');
	//if(
	
}

///////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////// functions for quotes ////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////

function getQuoteDescription($tick)
{	// get quote page for ticker
	$url = 'https://finance.yahoo.com/quote/' . $tick;
	$cont = get_page($url);

	preg_match("/<title[^>]*>(.*?)<\/title>/ims",$cont,$title);
	$tit = $title[1];
	$pos = strpos($tit, "("); // the ticker is enclosed in () after the title followed by useless stuff
	if($pos) $tit = substr($tit, 0, $pos - 1); // if title has a ( in it remove everything after + the space before it
	//$tit = strchr($title[1],"for");// remove characters before the first "for"
	//$tit = substr($tit, 4);// remove "for "
	//$tit = str_replace(" - Yahoo Finance","",$tit);// remove the end of title leaving only stock title
	return html_entity_decode($tit, ENT_QUOTES); // convert html entities( &lt; &amp; $quot; etc.) to text and return it
}

function displayQuotes($fid, $typ)
{	$db = new SQLite3('teds');
	$id = $typ . $fid;// create id for stock quotes
	// display table header in a separate table
	?>
	<table style="font-size:14px">
		<tr>
 			<th align="left" >Ticker</td>
			<th align="left" >Updated</td>
			<th>High</td> 
			<th>Low</td>
			<th>Close</td>
			<th title="Volume in blocks of 100">Volume</td>
			<th>Change</td>
		</tr>
	</table>
	<table style="font-size:14px">
		<tbody id="<?=$id?>" class="sqtarget">
	<?php
	// display quotes in a separate table so moves work properly
	$results = $db->query('SELECT * FROM quotes WHERE frameId = ' . $fid . ' ORDER BY pos');
	while ($row = $results->fetchArray(SQLITE3_BOTH)) displayQuote($fid, $row['id'], $row['ticker'], $row['title']);	
	?>
		</tbody>
	</table>
	<?php

}

// display initial stock quote row  and create script to get and display actual quote from internet (must run java eval function to actually run script)
function displayQuote($fid, $qid, $tkr, $tit)//fid = frames id, qid = id of qoute in database, tkr = ticker, tit = stock's description
{	$tit = str_replace('"','&quot;',$tit); // title can't contain " character, must use &quot; to display double quote
		?>
		<tr onmousedown="mouseDownHandler(event,this)" id="<?='qt' . $qid?>" onclick="quoteClick('<?=$tkr?>')"
		 oncontextmenu="rcQuote(event, <?=$qid?>);return false;" title="<?=$tit?>">
		 	<td style="cursor:pointer;"><?=$tkr?></td><script>updateQuote("<?='qt' . $qid?>", "<?=$tkr?>");</script>
			<td  rows="6">Loading...</td>
		</tr>
<?php
}


///////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////// function for bookmarks ////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////

function displayBookmarks($fid)// $fid is the frame id
{	$db = new SQLite3('teds');
	$results = $db->query('SELECT * FROM bookmarks WHERE frameId = ' . $fid . ' ORDER BY pos');
	$row = $results->fetchArray(SQLITE3_BOTH);
	if(!$row) return; /*{ ?> <div onmousedown="mouseDownHandler(event,this)"></div> <?php  return;}*/
	do { $row['description'] = str_replace('"','&quot;',$row['description']); // title can't contain " character, must use &quot; to display double quote
		?>
		<div id=<?="be" . $row['id']?> onmousedown="mouseDownHandler(event,this)" style="padding: 3px">
			<a oncontextmenu="rcBookmark(event, <?=$row['id']?>);return false;"href='<?=$row['url']?>' style="text-decoration:none"
			 target="_blank" title="<?=$row['description']?>"><img src="<?=$row['icon']?>" height='20' style="float:left">&nbsp;<?=$row['name']?></a>
		</div>
		<?php
	}while ($row = $results->fetchArray(SQLITE3_BOTH));
}


///////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////// functions for news feeds //////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////

// get articles from news feed and return in array of article arrays([date][title][desc][link][image])
function get_articles($nf, $srt = 1)// nf = news feed string, srt = sort(0 = no sort 1 = sort by date)
{	$rar = array();

	$nf = html_entity_decode($nf);// replace all HTML special characters(&lt; &gt; &quot; etc.) which will mess up several functions

	$ar = get_elements($nf, 'item');
	if(count($ar) == 0) $ar = get_elements($nf, 'entry');
	//echo count($ar);
	foreach ($ar as $its)
	{	$arr['date'] = '';$arr['title'] = '';$arr['desc'] = '';$arr['link'] = '';$arr['image'] = '';// clear article array

		// get update date string
		$iar = get_elements($its, 'updated');
		if(count($iar)) $upd = strip_tags($iar[0]);
		else{ $iar = get_elements($its, 'pubDate'); if(count($iar)) $upd = strip_tags($iar[0]);}
		if(!empty($upd))
		{	$date=date_create($upd);// create a date object from update date string
			date_timezone_set($date,timezone_open(date_default_timezone_get()));// adjust date to local time
			$arr['date'] = $date;
		}
		
		$iar = get_elements($its, 'title');
		if(count($iar) != 0)
		{	$arr['title'] = strip_tags(clear_CDATA($iar[0]));// get title (see clear_CDATA function for explanation)
			$iar = get_elements($its, 'description');
			if(count($iar) != 0) $arr['desc'] = strip_tags(clear_CDATA($iar[0]));// get description
		}
		// get link to article
		$iar = get_elements($its, 'link');
		if(count($iar) != 0)
		{	$lnk = strip_tags($iar[0]);
			if(empty($lnk)) $lnk = get_attribute($iar[0], 'href');
			$arr['link'] = $lnk;
		}
		// extract images from img element
		$iar = get_images($its); // not done
		foreach ( array_reverse($iar) as $val)
		{	if($val[0] == '/')// see if url starts with /
			{	if($val[1] == '/')// if url starts with // prepend http:
				{	$val = "http:" . $val;
				}
				else
				{// prepend base of site to url - NOT DONE
				}
			}
			//if( filter_var($val, FILTER_VALIDATE_URL)){// if url is not valid got to next one /////// this didn't work ///////
			list($wid, $hgt) = @getimagesize($val);
			if($wid > 40 && $hgt > 40)
			{	$arr['image'] = $val;
				break;
			}
		}

		if($srt > 0)// if sort is set sort article into the array
		{	$al = count($rar);// get array length
			for($a = 0; $a < $al; $a++) if($rar[$a]['date'] < $arr['date']) break; // find index of first date in array less than this article's date($a) 
			if($a == $al) $rar[] = $arr;// if it went through whole array add it to the end
			else // if not insert it in array
			{	for(; $al > $a; $al--) $rar[$al] = $rar[($al - 1)];// shift elements in array forward 1 spot, including $a
				$rar[$a] = $arr;// add this article to array at $a
			}
		}
		else $rar[] = $arr;// no sort, add it to the end of array
	}
	return $rar;	
}

// get images from rss element
function get_images($el)
{	$ar = array();
	// check for img tags
	$ar2 = get_elements($el, 'img');
	foreach ($ar2 as $val)
	{	$st = get_attribute($val, "src");
		if($st !== '') $ar[] = $st;	
	}
	// check for media:content tags
	$ar2 = get_elements($el, 'media:content');
	foreach ($ar2 as $val)
	{	$st = get_attribute($val, "url");
		if($st !== '') $ar[] = $st;	
	}
	// check for media:thumbnail tags
	$ar2 = get_elements($el, 'media:thumbnail');
	foreach ($ar2 as $val)
	{	$st = get_attribute($val, "url");
		if($st !== '') $ar[] = $st;	
	}
	// check for enclosure tags
	$ar2 = get_elements($el, 'enclosure');
	foreach ($ar2 as $val)
	{	$st = get_attribute($val, "url");
		if($st !== '') $ar[] = $st;	
	}
	return $ar;	
} 

// get attribute of element (if attribute is not in element this could pick up same attribute in sub element)
function get_attribute($el, $at)
{	$s = stripos( $el, $at . '=');// find start of attribute
	if($s === false) return '';
	$el = substr($el, ($s + strlen($at) + 1) ); // move the string to start of attribute before quote

	// move past leading spaces was never tested
	for(; strlen($el) > 0; $el = substr($el, 1)) if($el[0] != ' ') break; // move past leading spaces
	if(strlen($el) == 0) return '';

	if($el[0] == '"' || $el[0] == "'")
	{// find first quote mark and move string past it(may be " or ')
		$qt = '"'; // set quote mark to " 
		$s = strpos( $el, $qt);// check for position of "
		if($s === false)// if no " check for position of ' and use it if found
		{	$qt = "'"; // set quote
			$s = strpos( $el, $qt);// check for position of '
			if($s === false) return '';
		}
		else // there is a ". Check for '. If there is one use whichever is in the lowest position
		{	$ss = strpos( $el, "'");// check for position of '
			if($ss < $s){ $qt = "'"; $s = $ss;}// if position of ' is less than position of " use ' for quote mark
		}

		$el = substr($el, ($s + 1) ); // move the string to start of attribute

		$s = stripos( $el, $qt);// find end of attribute
		$el = substr($el, 0, $s);// end string there
	}
	else
	{	$s = stripos( $el, ' ');// find end of attribute (space)
		$el = substr($el, 0, $s);// end string there
	}
	return $el;

}

// get all elements by name. May be in any level. Element within the same element will mess this up(can be fixed if needed)
function get_elements($st, $el)// st = buffer, el = element name
{	$ar = array();	

	while(true)
	{	$s = stripos( $st, '<' . $el);// find start
		if($s === false) break;
		$st = substr($st, $s); // move the string to start of element
		$str = substr($st, (strlen($el) + 1), 1);// make a string containing character after element name
		if($str !== ' ' && $str !== '>')// if it is not space or >
		{	$st = substr( $st, strlen($el) ); // move past element name 
			continue; // continue while loop
		}

		$e = strpos( $st, '>');// get the position of the close of element definition
		if(substr($st, ($e - 1), 1) === '/')// if it is a self terminating element definition
		{	$e++;// Set end past >
		}
		else
		{	$e = stripos( $st, '</' . $el);// find end
			if($e === false)// if there is no </[element name] may be an empty element
			{	// if it is not a valid HTML empty element, break 
				if(!preg_match('/(area|base|br|col|embed|hr|img|input|keygen|link|meta|param|source|track|wbr)/i', $el) ){echo $el; echo "<br>"; break;}
				$e = (strpos( $st, '>') + 1);// it is a valid empty element. Set end past >
			}
			else // found element terminator
			{	$str = substr($st, $e);// make a string starting with element terminator
				$e = ($e + strpos( $str, '>') + 1);// Set end past >
			}
		}

		$ar[] = trim( substr($st, 0, $e) );// save HTML element to array
		$st = substr($st, $e);// move past element
	}
	return $ar;
}

// CDATA means character data which is data that can be iterpreted as XML (like --, <, &, ', ", etc,)
// anything between <![CDATA[ and  ]] is intended as text only
function clear_CDATA($st)
{	$st = str_replace('<![CDATA[','',$st);
	$st = str_replace(']]>','',$st);
	return $st;
}


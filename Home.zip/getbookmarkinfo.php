<?php
include 'functions.php';

function get_title($str){
    //$str = trim(preg_replace('/\s+/', ' ', $str)); // supports line breaks inside <title>
    preg_match("/<title[^>]*>(.*?)<\/title>/ims",$str,$title);
    //preg_match("/\<title\>(.*)\<\/title\>/i",$str,$title); // ignore case
    return $title[1];
}

// Need to load php7.0-xml to use DOMDocument
function get_disc($url){
    $doc = new DOMDocument();
    $internalErrors = libxml_use_internal_errors(true);//	$doc->strictErrorChecking = FALSE;
    $doc->loadHTML($url);
    $xml = simplexml_import_dom($doc);
	$x = 0;
    //$arr = $xml->xpath('//meta[@name="description"]');
	$arr = $xml->xpath('//meta[@name]');// get all meta tags with a name attribute
	// search for name attribute called "description"(case-insensitive) 
	for ($x = 0; $x < count($arr); $x++) if(!strcmp(strtolower($arr[$x]['name']), "description")) break;
    // if no attribute named "description" search meta tag name attributes that contain sub string "description"(case-insensitive) 
	if($x == count($arr))
	{	for ($x = 0; $x < count($arr); $x++) if(strrchr(strtolower($arr[$x]['name']), "description")) break;
	}
    if($x < count($arr)) return $arr[$x]['content'];
	else return 'No description';
}

function unparse_url($parsed_url) {
  $scheme   = isset($parsed_url['scheme']) ? $parsed_url['scheme'] . '://' : '';
  $host     = isset($parsed_url['host']) ? $parsed_url['host'] : '';
  $port     = isset($parsed_url['port']) ? ':' . $parsed_url['port'] : '';
  $user     = isset($parsed_url['user']) ? $parsed_url['user'] : '';
  $pass     = isset($parsed_url['pass']) ? ':' . $parsed_url['pass']  : '';
  $pass     = ($user || $pass) ? "$pass@" : '';
  $path     = isset($parsed_url['path']) ? $parsed_url['path'] : '';
  $query    = isset($parsed_url['query']) ? '?' . $parsed_url['query'] : '';
  $fragment = isset($parsed_url['fragment']) ? '#' . $parsed_url['fragment'] : '';
  return "$scheme$user$pass$host$port$path$query$fragment";
}

function get_icon($url, $cont){
	$urlparts = parse_url($url); // get parts to url ie. for "https://www.anurl.com/some/path/" scheme = https, host = www.anurl.com, path = /some/path

	/*/ look for shortcut icon link
	$doc = new DOMDocument();
	$internalErrors = libxml_use_internal_errors(true);//	$doc->strictErrorChecking = FALSE;
	$doc->loadHTML($cont);
	$xml = simplexml_import_dom($doc);
	$arr = $xml->xpath('//link[@rel="shortcut icon"]');// get all links with attribute rel="shortcut icon"
	$icol = $arr[0]['href']; // get icon url of first link
	$icparts = parse_url($icol);// get parts of url
	if(!strlen($icparts[scheme])) $icparts[scheme] = $urlparts[scheme];// if scheme is missing in icon link use the one from base pege
	if(!strlen($icparts[host])) $icparts[host] = $urlparts[host];// do the same as above for host
	$icol = unparse_url($icparts);// reassemble icon url
	if(!strncmp(get_mime($icol), "image", 5)) return $icol; // if mime is an image return
	// look for uppercase shortcut icon link
	$arr = $xml->xpath('//link[@rel="SHORTCUT ICON"]');// get all links with attribute rel="SHORTCUT ICON"
	$icol = $arr[0]['href']; // get icon url of first link
	$icparts = parse_url($icol);// get parts of url
	if(!strlen($icparts[scheme])) $icparts[scheme] = $urlparts[scheme];// if scheme is missing in icon link use the one from base pege
	if(!strlen($icparts[host])) $icparts[host] = $urlparts[host];// do the same as above for host
	$icol = unparse_url($icparts);// reassemble icon url
	if(!strncmp(get_mime($icol), "image", 5)) return $icol; // if mime is an image return
	// look for icon link 
	$arr = $xml->xpath('//link[@rel="icon"]');// get all links with attribute rel="SHORTCUT ICON"
	$icol = $arr[0]['href']; // get icon url of first link
	$icparts = parse_url($icol);// get parts of url
	if(!strlen($icparts[scheme])) $icparts[scheme] = $urlparts[scheme];// if scheme is missing in icon link use the one from base pege
	if(!strlen($icparts[host])) $icparts[host] = $urlparts[host];// do the same as above for host
	$icol = unparse_url($icparts);// reassemble icon url
	if(!strncmp(get_mime($icol), "image", 5)) return $icol; // if mime is an image return
////*/

	// check for link to 'shortcut icon' or 'icon'
	$hd = get_elements($cont, 'head');// get header
	$ls = get_elements($hd[0], 'link');// get links in header
	foreach($ls as $lk)
	{	$re = get_attribute($lk, 'rel');// get rel attribute
		$re = strtolower($re); // convert rel value to lowercase
		if($re !== 'shortcut icon' && $re !== 'icon') continue;// if not 'shortcut icon' or 'icon' goto next link
		$icol = get_attribute($lk, 'href');// get url of icon
		$icparts = parse_url($icol);// get parts of url
		if(!array_key_exists('scheme', $icparts)) $icparts['scheme'] = $urlparts['scheme'];// if scheme is missing in icon link use the one from base pege
		if(!array_key_exists('host', $icparts)) $icparts['host'] = $urlparts['host'];// do the same as above for host
		$icol = unparse_url($icparts);// reassemble icon url
		if(!strncmp(get_mime($icol), "image", 5)) return $icol; // if mime is an image return
	}
////*/

	// try /favicon.ico
	//$icparts = parse_url("/favicon.ico");
	$icol = $url."/favicon.ico";
	if(!strncmp(get_mime($icol), "image", 5)) return $icol; // if mime is an image return

	// try /favicon.ico on host base address
	$ar = array("scheme"=>$urlparts['scheme'], "host"=>$urlparts['host'], "path"=>"/favicon.ico");
	$icol = unparse_url($ar);
	if(!strncmp(get_mime($icol), "image", 5)) return $icol; // if mime is an image return
	else return "";

}

$url=$_GET["q"];
$cont = get_page($url);
if(!strlen($cont)) return;
echo get_title($cont);
echo "\036";
echo get_icon($url, $cont);
echo "\036";
echo get_disc($cont);

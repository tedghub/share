<?php

function getQuote($tk)
{	$day = 86400; // 1 day in seconds
	$today = time();
	$start = $today - $day * 6; // 6 days ago

	$ch = curl_init();
	$url = 'https://query1.finance.yahoo.com/v7/finance/download/' . $tk . '?period1=' . $start . '&period2=' . $today . '&interval=1d&events=history&crumb=H.rifS1ZImr';
	#file_put_contents('GetQuoteDebug', $url . "\r\n", FILE_APPEND | LOCK_EX);
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_COOKIE, 'B=35schthd28bhc&b=3&s=e2');
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE); //returns results to a variable (not to screen)
	$data = curl_exec($ch);
	curl_close($ch);

	$rows = explode(PHP_EOL, $data);// make array of lines returned
	$rowLen = count($rows) - 1; // get index of last row
	if(empty($rows[$rowLen])) $rowLen--;// last row is blank sometimes so make count 1 less if it is
#file_put_contents('GetQuoteDebug', ">" . $rows[$rowLen] . "<\r\n", FILE_APPEND | LOCK_EX);
	if($rowLen < 3) return 0; //must have header and al least 2 entries
	for($x = 0; $x <= $rowLen; $x++) $rows[$x] = explode(',', $rows[$x]);// make rows a 2 dimensional array of entries
	$colLen = count($rows[0]);// number of columns
	for($y = 0; $y < $colLen; $y++)// go through header and find Date High Low Close and Volume index and put them in the srt array
	{	if($rows[0][$y][0]=='D') $srt[0]=$y;
		if($rows[0][$y][0]=='H') $srt[1]=$y;
		if($rows[0][$y][0]=='L') $srt[2]=$y;
		if($rows[0][$y][0]=='C') $srt[3]=$y;
		if($rows[0][$y][0]=='V') $srt[4]=$y;
	}
	// set qar array variables from last entry in rows using sort array indexes
	$qar['date'] = date_format(date_create($rows[$rowLen][$srt[0]]),"m/d/y");
	$qar['high'] = number_format($rows[$rowLen][$srt[1]], 2, '.', '');
	$qar['low'] = number_format($rows[$rowLen][$srt[2]], 2, '.', '');
	$qar['close'] = number_format($rows[$rowLen][$srt[3]], 2, '.', '');
	$qar['volume'] = number_format($rows[$rowLen][$srt[4]] / 100, 0, '', ',');;
	$qar['prClose'] = number_format($rows[$rowLen - 1][$srt[3]], 2, '.', '');// previous day close
	return $qar;
}

$arr = getQuote($_GET["tick"]);
$ch = number_format($arr['close'] - $arr['prClose'], 2, '.', '');// get change
if($ch < 0) $clr = 'Red'; else $clr = 'Green'; // if < 0 color change Red otherwise Green
$change = $ch . '(' . number_format($ch/$arr['prClose']*100, 2, '.', '') . '%)';// make string of change and percent
echo $_GET["htmlId"] . "\036"; // send target element id back to AJAX
//file_put_contents('debug', $_GET["htmlId"] . "\r\n", FILE_APPEND | LOCK_EX);
?>
<td style="cursor:pointer;"><?=$_GET["tick"]?></td>
<td><?=$arr['date']?></td>
<td align="right" ><?=$arr['high']?></td>
<td align="right" ><?=$arr['low']?></td>
<td align="right" ><?=$arr['close']?></td>
<td align="right" ><?=$arr['volume']?></td>
<td style="color:<?=$clr?>;" align="right" ><?=$change?> </td>


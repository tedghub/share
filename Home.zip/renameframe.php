<?php
$db = new SQLite3('teds');
$st = str_replace('"','""',$_GET['t']);
$db->exec('UPDATE frames Set title="' . $st . '" WHERE id=' . $_GET['f']);

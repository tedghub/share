
// update quotes on web page. id = id for HTML table row, tick = ticker symbol.
function updateQuote(id, tick){ phpToHtlm('updatequote.php', id, '&tick=' + tick);}

// Create quote from add quote dialog, put it in dbase and update it.(if valid ticker)
function createQuote(id)
{	myFunction('edQtModal');// close dialog

	fun = function()
	{	if(PhpResult === ''){ alert(document.getElementById('edQtTk').value + " ticker not found"); return;}
		tbody = document.getElementById(id).getElementsByTagName("TBODY")[1];// get quote's table's second tbody element (first tbody is header) 
		tbody.appendChild( html2element(PhpResult.trim()) );// append new quotes row into it
		eval(tbody.getElementsByTagName("script")[0].innerHTML); // execute the quote update script
	};
	getPhp('createquote.php', "fid=" + id + "&tkr=" + document.getElementById('edQtTk').value + "&tit=" + encodeURIComponent(document.getElementById('edQtTit').value), fun);
}

function addQuote(id)//run add quote dialog. id is the quotes list id
{	
	document.getElementById('qtEdHd').innerHTML = 'Add Stock Quote'; // set dialog title
	document.getElementById('edQtTk').value = '';// clear ticker input
	document.getElementById('edQtTit').value = '';// clear description input
	// set the onclick function in add bookmark dialog
	document.getElementById('edTkSv').onclick = function() {createQuote(id);}
	myFunction('edQtModal');// run dialog
}

function getQuoteDesc(tk)
{	fun = function() // set description in dialog
	{	if(PhpResult === '') PhpResult = "Ticker not found";
		document.getElementById('edQtTit').value = PhpResult;
	};
	getPhp("./getquotetitle.php","tick=" + document.getElementById(tk).value, fun);
}

// run quote context(right click) menu
function rcQuote(event, id)// event = event structure, id = quote id
{	// set onclick functions in quote context menu
	par = event.target.parentNode;// get parent this is the div that contains quote to delete or move
	document.getElementById('rcqd').onclick = function() {dbdelete('quotes', id, par); myFunction('rcQtModal');}// delete quote and close dialog
	document.getElementById('rcqmu').onclick = function() {moveQt(id, par, -1);}
	document.getElementById('rcqmd').onclick = function() {moveQt(id, par, 1);}
	document.getElementById('rcqed').onclick = function() {alert("Edit quote under construction.\nMay not be useful."); myFunction('rcQtModal');}
	myFunction('rcQtModal');// open dialog (rcQtModal is the modal screen)
	locatePopup('rcQtCont', event); // position it relative to cursor and in window (rcQtCont is the actual popup)
}

function moveQt(id, el, dir)// id = sql table's bookmark id, el = html element dir = direction(-1 = up 1 = down)
{	// move item in database
	fun = function() { myFunction('rcQtModal');}; // the ajax responseText is PhpResult(cannot rename it)
	getPhp("./moveitem.php","tb='quotes'&id=" + id + "&dr=" + dir, fun);

	moveItem(el, dir)// move item on web page
}

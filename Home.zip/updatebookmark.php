<?php
include 'functions.php';

$db = new SQLite3('teds');
$st = str_replace('"','""',$_GET['q']);
$ar = explode("\036", $st);// parse separated string into an array
$db->exec('UPDATE bookmarks Set url="' . $ar[0] . '", name="' . $ar[1] . '", icon="' . $ar[2] . '", description="' . $ar[3] . '" WHERE id=' . $ar[4]);

// get frame id for the bookmark($row[0]) and rewrite bookmarks frame
$results = $db->query('SELECT frameId From bookmarks where id=' . $ar[4]);
$row = $results->fetchArray(SQLITE3_BOTH);
displayBookmarks($row[0]);


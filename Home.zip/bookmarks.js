// open bookmark edit dialog to add bookmark
function addBookmark(id)// id is the bookmarks list id
{	clearAddBookmark();
	document.getElementById('BmEdHd').innerHTML = 'Add Bookmark'; // set dialog title
	document.getElementById('it1').value = '';// clear url input
	// set the onclick function in add bookmark dialog
	document.getElementById('addBut').onclick = function() {storeBookmark(document.getElementById('it1').value, id);}
	myFunction('myModal');// run dialog
}

// run bookmark context(right click) menu
function rcBookmark(event, id)// event = event structure, id = bookmark id
{	// set onclick functions in bookmark context menu
	par = event.target.parentNode;// get parent this is the div that contains bookmark to delete or move
	document.getElementById('rcd').onclick = function() {dbdelete('bookmarks', id, par); myFunction('rcBmModal');}// delete bookmark and close dialog
	document.getElementById('rcmu').onclick = function() {moveBm(id, par, -1);}
	document.getElementById('rcmd').onclick = function() {moveBm(id, par, 1);}
	document.getElementById('rced').onclick = function() {editBm(id, par);}
	myFunction('rcBmModal');// open dialog
	locatePopup('rcBmCont', event); // position it relative to cursor and in window
}

// fill and open bookmark edit dialog to edit bookmark
function editBm(id, par)
{	myFunction('rcBmModal'); // close rightclick dialog
	document.getElementById('BmEdHd').innerHTML = 'Edit Bookmark';// set dialog title
	document.getElementById('addBut').onclick = function() {updateBookmark(id, par);}
	document.getElementById('livesearch').innerHTML = '&nbsp';// clear info in bookmark edit dialog
	// fill edit dialog fields
	fun = function()
	{	res = PhpResult.split("\036");// the ajax responseText is PhpResult(cannot rename it)
		document.getElementById('it1').value = res[0];
		document.getElementById('tit').value = res[1];
		document.getElementById('icn').value = res[2];
		document.getElementById('disicn').src = res[2];
		document.getElementById('des').value = res[3];
		document.getElementById('addBut').disabled = false;// turn add button on
		myFunction('myModal');// run edit dialog
	}; 
	getPhp("./querybookmark.php","q=" + id, fun);
}

// rewrite bookmark
function updateBookmark(id, par)
{	sp = "\036";
	// create a separated string with url title icon description (from bookmark dialog) and bookmark id
	str = document.getElementById('it1').value + sp + document.getElementById('tit').value + sp + document.getElementById('icn').value + sp + document.getElementById('des').value + sp + id;
	str = encodeURIComponent(str); // do a URI encode because php get does a decode which may cause problems if certain characters are in string
	gp = par.parentNode; // get grandparent (the bookmark list to update)
	fun = function(){ myFunction('myModal'); gp.innerHTML = PhpResult;};// close edit dialog and write bookmarks 
	getPhp("./updatebookmark.php","q=" + str, fun);
}

function moveBm(id, el, dir)// id = sql table's bookmark id, el = html element dir = direction(-1 = up 1 = down)
{	// move item in database
	fun = function() { myFunction('rcBmModal');}; // the ajax responseText is PhpResult(cannot rename it)
	getPhp("./moveitem.php","tb='bookmarks'&id=" + id + "&dr=" + dir, fun);

	moveItem(el, dir)// move item on web page
}

function clearAddBookmark()// clear fields in add bookmark dialog (except url)
{	document.getElementById('tit').value = '';
	document.getElementById('icn').value = '';
	document.getElementById('disicn').src = 'icons/no-icon.ico';
	document.getElementById('des').value = '';
	document.getElementById('livesearch').innerHTML = '&nbsp';
	document.getElementById('addBut').disabled = true;
}

function storeBookmark(str, id)
{	document.getElementById("livesearch").innerHTML="Storing '" + str + "'";
    if (str.length==0){ document.getElementById("livesearch").innerHTML=""; return;}

	sep = "\036";
	str = str.concat(sep, document.getElementById('tit').value, sep, document.getElementById('icn').value, sep, document.getElementById('des').value, sep, id);
	str = encodeURIComponent(str);

	fun = function() { document.getElementById(id).innerHTML = PhpResult; myFunction('myModal');}; // the ajax responseText is PhpResult(cannot rename it). myFunction closes dialog
	getPhp("./storebook.php","q=" + str, fun);
}

function showResult(str) {
    document.getElementById("livesearch").innerHTML="Processing '" + str + "'";
    st = new Date().getTime();
	fun = function(){ 
				tt = new Date().getTime() - st;
				if(PhpResult === '')
				{	document.getElementById("livesearch").innerHTML="Invalid url'" + str + "'";
					return;
				}
				document.getElementById("livesearch").innerHTML = "Process Time : " + tt/1000 + " Seconds";
				res = PhpResult.split("\036");
				document.getElementById('tit').value = res[0];
				document.getElementById('icn').value = res[1];
				document.getElementById('disicn').src = res[1];
				document.getElementById('des').value = res[2];
				document.getElementById('addBut').disabled = false;// turn add button on
		}; // the ajax responseText is PhpResult(cannot rename it)
	getPhp("./getbookmarkinfo.php","q=" + encodeURIComponent(str), fun);
}


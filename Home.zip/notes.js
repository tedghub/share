var ntBuff= new Object; // create an object to contain notes original text (by frame id)
var ntTOut = 0; // timeout for note save reminder

function noteCleanup(id)
{	document.getElementById('ntsv' + id).className = 'w3-hide';// hide save and cancel buttons
	delete ntBuff[id];// remove restore buffer for this note
	noteRemind(); // update/close save note reminder dialog
}

function saveNote(fid, el)// save note contents to database. fid = frame id el = note element 
{	//alert(fid + ' - ' + el); return;	
	fun = function() { noteCleanup(fid);};
	getPhp("./savenote.php","f=" + fid + "&c=" + encodeURIComponent(el.innerHTML), fun);
}

function noteChange(id)// note content changed. id = frame id
{	document.getElementById('ntsv' + id).className = 'w3-show';
	if(ntTOut == 0) ntTOut = setInterval(noteRemind, 300000);// if timeout not active set nag for 5 minute intervals
	if(document.getElementById('ntSvRem').className == 'w3-show') noteRemind(); // update save note reminder dialog if it is showing
}

function noteFocus(id)// save note content so it can be restored on cancel
{	// if it wasn't already saved save it (this stops the content from being resaved after changes on multiple focuses)
	if(!ntBuff[id]) ntBuff[id] = document.getElementById('nt' + id).innerHTML;
}

function noteCancel(id)// note cancel button click
{	document.getElementById('nt' + id).innerHTML = ntBuff[id];// restore note to original
	noteCleanup(id);
}

function noteRemind()
{	st = '';
	for(var key in ntBuff)// go through key titles in object ntBuff
 	{	ns = document.getElementById('ntsv' + key);
		if(ns.className == 'w3-hide') continue; // if the save dialog isn't visible, skip to next one
		st += '(' + ns.previousElementSibling.innerText + ')<br>';
	}
    if(st === ''){ clearInterval(ntTOut); ntTOut = 0; document.getElementById('ntSvRem').className = 'w3-hide';return;} 
	// update save note reminder dialog
	//alert('You need to save the following lists\n' + st);
	document.getElementById("ntSvRemNts").innerHTML = st;
	document.getElementById('ntSvRem').className = 'w3-show';
	//myFunction('ntSvRem');
}

function ntKeyDown(e)
{	if(event.key != "Tab") return;
	e.preventDefault();
    /*var sel, range;
    if (window.getSelection) {
        sel = window.getSelection();
        if (sel.getRangeAt && sel.rangeCount) {
            range = sel.getRangeAt(0);
            range.deleteContents();
            range.insertNode( document.createTextNode("   ") );
        }
    } else if (document.selection && document.selection.createRange) {
        document.selection.createRange().text = "    ";
    }/////*/
}

<?php
include 'functions.php';
// display frames in column (q) onmousedown="frMouseDown(event,this)" 
$db = new SQLite3('teds');
$results = $db->query('SELECT * FROM frames WHERE column = ' . $_GET["q"] . ' ORDER BY pos');
while ($row = $results->fetchArray(SQLITE3_BOTH))
{
?>
<div id=<?="fr" . $row['id']?> > 
<?php displayFrame($row['id'], $row['type'], $row['title'], $row['contents']); ?>
</div>
<?php
}


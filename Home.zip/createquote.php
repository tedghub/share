<?php
include 'functions.php';
$db = new SQLite3('teds');

$qd = trim(getQuoteDescription($_GET["tkr"]));// get quote description and trim it
if($qd === '') echo '';// If invalid ticker return empty string.
else // save ticker to database and return HTML table row for display
{
$fid = $_GET["fid"];
$tk = strtoupper($_GET["tkr"]);
$t = $_GET["tit"];
if($t === '') $t = $qd; // if quote title is blank use discription from yahoo

// create next id for quotes
$results = $db->query('SELECT MAX(id) AS max_id FROM quotes'); // get highest id in quotes
$row = $results->fetchArray(SQLITE3_BOTH);
$id = $row["max_id"] + 1;

$fn = substr($fid, 2); // get frame number from frame's HTML id
// create next position in frame
$results = $db->query('SELECT MAX(pos) AS max_pos FROM quotes where frameId=' . $fn); // get highest position number in frame
$row = $results->fetchArray(SQLITE3_BOTH);
$p = $row["max_pos"] + 1;

// add quote to database
$db->exec('INSERT INTO quotes (id, ticker, title, frameId, pos) VALUES (' . $id . ',"' . $tk . '","' . $t . '",' .  $fn . ',' . $p . ')');

displayQuote($fid, $id, $tk, $t);
}
